<?php
require('../makefont/makefont.php');
MakeFont('THSarabun.ttf','cp874');
MakeFont('THSarabun Bold.ttf','cp874');
?>