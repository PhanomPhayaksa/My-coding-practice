<div class="alert alert-danger" role="alert">
    <?php echo $message;?>
</div>