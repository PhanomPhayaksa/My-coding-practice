<div class="alert alert-success" role="alert">
    <?php echo $message; ?>
</div>