<!DOCTYPE html>
<html>
<head>
    <title>ดึงข้อมูลนักศึกษาฝึกงาน</title>
</head>
<body>
    <h2>กรอกรหัสนักศึกษา</h2>
    <form method="POST" action="reportdb.php">
        <input type="text" name="studentID" placeholder="รหัสนักศึกษา" required>
        <button type="submit">ดึงข้อมูล</button>
    </form>
</body>
</html>
