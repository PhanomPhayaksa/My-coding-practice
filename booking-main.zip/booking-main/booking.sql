-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2023 at 07:24 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `booking`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking_category`
--

CREATE TABLE `booking_category` (
  `Field` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  `category_id` varchar(10) DEFAULT '0',
  `topic` varchar(150) NOT NULL,
  `color` varchar(16) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `booking_category`
--

INSERT INTO `booking_category` (`Field`, `type`, `category_id`, `topic`, `color`, `published`) VALUES
(1, 'department', '1', 'นักศึกษา', NULL, 1),
(2, 'department', '2', 'คณะอาจารย์', NULL, 1),
(3, 'department', '3', 'อื่นๆ(เขียนในช่องรายละเอียดให้ด้วยนะ)', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `booking_language`
--

CREATE TABLE `booking_language` (
  `id` int(11) NOT NULL,
  `key` text NOT NULL,
  `type` varchar(5) NOT NULL,
  `owner` varchar(20) NOT NULL,
  `js` tinyint(1) NOT NULL,
  `th` text DEFAULT NULL,
  `en` text DEFAULT NULL,
  `la` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `booking_language`
--

INSERT INTO `booking_language` (`id`, `key`, `type`, `owner`, `js`, `th`, `en`, `la`) VALUES
(1, 'ACCEPT_ALL', 'text', 'index', 1, 'ยอมรับทั้งหมด', 'Accept all', 'ຍອມຮັບທັງຫມົດ'),
(2, 'CANCEL', 'text', 'index', 1, 'ยกเลิก', 'Cancel', 'ຍົກເລີກ'),
(3, 'CHANGE_COLOR', 'text', 'index', 1, 'เปลี่ยนสี', 'change color', 'ປ່ຽນສີ'),
(4, 'CHECK', 'text', 'index', 1, 'เลือก', 'check', 'ເລືອກ'),
(5, 'CHECKBOX', 'text', 'index', 1, 'ตัวเลือก', 'Checkbox', 'ກ່ອງກາເຄື່ອງໝາຍ'),
(6, 'COOKIES_SETTINGS', 'text', 'index', 1, 'ตั้งค่าคุกกี้', 'Cookies settings', 'ຕັ້ງຄ່າຄຸກກີ'),
(7, 'DELETE', 'text', 'index', 1, 'ลบ', 'delete', 'ລຶບ'),
(8, 'DISABLE', 'text', 'index', 1, 'ปิดใช้งาน', 'Disable', 'ປິດໃຊ້ການ'),
(9, 'ENABLE', 'text', 'index', 1, 'เปิดใช้งาน', 'Enable', 'ເປີດໃຊ້ການ'),
(10, 'INVALID_DATA', 'text', 'index', 1, 'ข้อมูล XXX ไม่ถูกต้อง', 'XXX Invalid data', 'ຂໍ້ມູນ XXX ບໍ່ຖືກຕ້ອງ'),
(11, 'NEXT_MONTH', 'text', 'index', 1, 'เดือนถัดไป', 'Next Month', 'ເດືອນຕໍ່ໄປ'),
(12, 'PLEASE_BROWSE_FILE', 'text', 'index', 1, 'กรุณาเลือกไฟล์', 'Please browse file', 'ກະລຸນາເລືອກແຟ້ມຂໍ້ມູນ'),
(13, 'PLEASE_FILL_IN', 'text', 'index', 1, 'กรุณากรอก', 'Please fill in', 'ກະລຸນາພີ່ມ'),
(14, 'PLEASE_SAVE_BEFORE_CONTINUING', 'text', 'index', 1, 'กรุณาบันทึก ก่อนดำเนินการต่อ', 'Please save before continuing', 'ກະລຸນາບັນທຶກກ່ອນດຳເນີນການຕໍ່'),
(15, 'PLEASE_SELECT', 'text', 'index', 1, 'กรุณาเลือก', 'Please select', 'ກະລຸນາເລືອກ'),
(16, 'PLEASE_SELECT_AT_LEAST_ONE_ITEM', 'text', 'index', 1, 'กรุณาเลือก XXX อย่างน้อย 1 รายการ', 'Please select XXX at least one item', 'ກະລຸນາເລືອກ XXX ຢ່າງໜ້ອຍໜຶ່ງລາຍການ'),
(17, 'PREV_MONTH', 'text', 'index', 1, 'เดือนก่อนหน้า', 'Prev Month', 'ເດືອນທີ່ຜ່ານມາ'),
(18, 'SELECT_ALL', 'text', 'index', 1, 'เลือกทั้งหมด', 'select all', 'ເລືອກທັງໝົດ'),
(19, 'SELECT_NONE', 'text', 'index', 1, 'ไม่เลือกรายการใดเลย', 'select none', 'ບໍ່ເລືອກລາຍການໃດເລີຍ'),
(20, 'SORRY_XXX_NOT_FOUND', 'text', 'index', 1, 'ขออภัย ไม่พบ XXX ที่ต้องการ', 'Sorry XXX not found', 'ຂໍອະໄພບໍ່ພົບ XXX ທີ່ຕ້ອງການ'),
(21, 'SUCCESSFULLY_COPIED_TO_CLIPBOARD', 'text', 'index', 1, 'สำเนาไปยังคลิปบอร์ดเรียบร้อย', 'Successfully copied to clipboard', 'ສຳເນົາໄປຍັງຄິບບອດຮຽບຮ້ອຍ'),
(22, 'SUCCESSFULLY_UPLOADED_XXX_FILES', 'text', 'index', 1, 'อัปโหลดเรียบร้อย XXX ไฟล์', 'Successfully uploaded XXX files', 'ອັບໂຫຼດຮຽບຮ້ອຍ XXX ແຟ້ມ'),
(23, 'THE_TYPE_OF_FILE_IS_INVALID', 'text', 'index', 1, 'ชนิดของไฟล์ไม่ถูกต้อง', 'The type of file is invalid', 'ຊະນິດຂອງແຟ້ມບໍ່ຖືກຕ້ອງ'),
(24, 'UNCHECK', 'text', 'index', 1, 'ไม่เลือก', 'uncheck', 'ບໍ່ເລືອກ'),
(25, 'YOU_WANT_TO_XXX', 'text', 'index', 1, 'คุณต้องการ XXX ?', 'You want to XXX ?', 'ທ່ານບໍ່ຕ້ອງການ XXX ?'),
(26, 'YOU_WANT_TO_XXX_THE_SELECTED_ITEMS', 'text', 'index', 1, 'คุณต้องการ XXX รายการที่เลือก ?', 'You want to XXX the selected items ?', 'ທ່ານຕ້ອງການ XXX ລາຍການທີ່ເລືອກ?'),
(27, 'APPROVING_RESERVATIONS', 'array', 'index', 0, 'a:3:{i:0;s:42:\"ก่อนหมดเวลาจอง\";i:1;s:42:\"ก่อนถึงเวลาจอง\";i:2;s:24:\"ตลอดเวลา\";}', 'a:3:{i:0;s:14:\"End of booking\";i:1;s:19:\"Before booking time\";i:2;s:8:\"All time\";}', 'a:3:{i:0;s:39:\"ສິ້ນສຸດການຈອງ\";i:1;s:48:\"ກ່ອນທີ່ຈະຈອງເວລາ\";i:2;s:30:\"ຕະຫຼອດເວລາ\";}'),
(28, 'BOOKING_OPTIONS', 'array', 'index', 0, 'a:1:{s:11:\"accessories\";s:21:\"อุปกรณ์\";}', 'a:1:{s:11:\"accessories\";s:11:\"Accessories\";}', 'a:1:{s:11:\"accessories\";s:21:\"ອຸປະກອນ\";}'),
(29, 'BOOKING_SELECT', 'array', 'index', 0, 'a:2:{s:3:\"use\";s:27:\"ใช้สำหรับ\";s:10:\"department\";s:36:\"แผนกที่ขอใช้\";}', 'a:2:{s:3:\"use\";s:7:\"use for\";s:10:\"department\";s:20:\"Requested department\";}', 'a:2:{s:3:\"use\";s:27:\"ໃຊ້ສໍາລັບ\";s:10:\"department\";s:33:\"ພະແນກຮ້ອງຂໍ\";}'),
(30, 'BOOKING_STATUS', 'array', 'index', 0, 'a:5:{i:0;s:27:\"รอตรวจสอบ\";i:1;s:21:\"อนุมัติ\";i:2;s:30:\"ไม่อนุมัติ\";i:3;s:45:\"ยกเลิกโดยผู้จอง\";i:4;s:60:\"ยกเลิกโดยเจ้าหน้าที่\";}', 'a:5:{i:0;s:7:\"Pending\";i:1;s:7:\"Approve\";i:2;s:11:\"Not allowed\";i:3;s:20:\"Canceled by customer\";i:4;s:23:\"Canceled by the officer\";}', 'a:5:{i:0;s:57:\"ລໍຖ້າສໍາລັບການກວດກາ\";i:1;s:21:\"ອະນຸມັດ\";i:2;s:30:\"ບໍ່ອະນຸຍາດ\";i:3;s:66:\"ຍົກເລີກໂດຍບຸກຄົນທີ່ຈອງ\";i:4;s:63:\"ຍົກເລີກໂດຍເຈົ້າໜ້າທີ່\";}'),
(31, 'BOOLEANS', 'array', 'index', 0, 'a:2:{i:0;s:27:\"ปิดใช้งาน\";i:1;s:30:\"เปิดใช้งาน\";}', 'a:2:{i:0;s:7:\"Disable\";i:1;s:7:\"Enabled\";}', 'a:2:{i:0;s:27:\"ປິດໃຊ້ວຽກ\";i:1;s:30:\"ເປີດໃຊ້ວຽກ\";}'),
(32, 'CANCEL_RESERVATIONS', 'array', 'index', 0, 'a:3:{i:0;s:42:\"สถานะรอตรวจสอบ\";i:1;s:42:\"ก่อนถึงเวลาจอง\";i:2;s:42:\"ก่อนหมดเวลาจอง\";}', 'a:3:{i:0;s:14:\"Pending status\";i:1;s:19:\"Before booking time\";i:2;s:14:\"End of booking\";}', 'a:3:{i:0;s:57:\"ສະຖານະທີ່ຍັງຄ້າງຢູ່\";i:1;s:48:\"ກ່ອນທີ່ຈະຈອງເວລາ\";i:2;s:39:\"ສິ້ນສຸດການຈອງ\";}'),
(33, 'DATE_FORMAT', 'text', 'index', 0, 'd M Y เวลา H:i น.', 'd M Y, H:i', 'd M Y ເວລາ H:i'),
(34, 'DATE_LONG', 'array', 'index', 0, 'a:7:{i:0;s:21:\"อาทิตย์\";i:1;s:18:\"จันทร์\";i:2;s:18:\"อังคาร\";i:3;s:9:\"พุธ\";i:4;s:24:\"พฤหัสบดี\";i:5;s:15:\"ศุกร์\";i:6;s:15:\"เสาร์\";}', 'a:7:{i:0;s:6:\"Sunday\";i:1;s:6:\"Monday\";i:2;s:7:\"Tuesday\";i:3;s:9:\"Wednesday\";i:4;s:8:\"Thursday\";i:5;s:6:\"Friday\";i:6;s:8:\"Saturday\";}', 'a:7:{i:0;s:15:\"ອາທິດ\";i:1;s:9:\"ຈັນ\";i:2;s:18:\"ອັງຄານ\";i:3;s:9:\"ພຸດ\";i:4;s:15:\"ພະຫັດ\";i:5;s:9:\"ສຸກ\";i:6;s:12:\"ເສົາ\";}'),
(35, 'DATE_SHORT', 'array', 'index', 0, 'a:7:{i:0;s:7:\"อา.\";i:1;s:4:\"จ.\";i:2;s:4:\"อ.\";i:3;s:4:\"พ.\";i:4;s:7:\"พฤ.\";i:5;s:4:\"ศ.\";i:6;s:4:\"ส.\";}', 'a:7:{i:0;s:2:\"Su\";i:1;s:2:\"Mo\";i:2;s:2:\"Tu\";i:3;s:2:\"We\";i:4;s:2:\"Th\";i:5;s:2:\"Fr\";i:6;s:2:\"Sa\";}', 'a:7:{i:0;s:4:\"ທ.\";i:1;s:4:\"ຈ.\";i:2;s:4:\"ຄ.\";i:3;s:4:\"ພ.\";i:4;s:4:\"ພ.\";i:5;s:4:\"ສ.\";i:6;s:4:\"ສ.\";}'),
(36, 'LINE_FOLLOW_MESSAGE', 'text', 'index', 0, 'สวัสดี คุณ :name นี่คือบัญชีทางการของ :title เราจะส่งข่าวสารถึงคุณผ่านช่องทางนี้', 'Hello, :name This is :title official account. We will send you news via this channel.', 'ສະບາຍດີ, :name ນີ້ແມ່ນບັນຊີທາງການຂອງ :title ພວກເຮົາຈະສົ່ງຂ່າວໃຫ້ທ່ານຜ່ານຊ່ອງທາງນີ້.'),
(37, 'LINE_REPLY_MESSAGE', 'text', 'index', 0, 'ขออภัยไม่สามารถตอบกลับข้อความนี้ได้', 'Sorry, can&#039;t reply to this message.', 'ຂໍອະໄພ, ບໍ່ສາມາດຕອບກັບຂໍ້ຄວາມນີ້ໄດ້.'),
(38, 'LOGIN_FIELDS', 'array', 'index', 0, 'a:4:{s:8:\"username\";s:30:\"ชื่อผู้ใช้\";s:5:\"email\";s:15:\"อีเมล\";s:5:\"phone\";s:39:\"เบอร์โทรศัพท์\";s:7:\"id_card\";s:30:\"เลขประชาชน\";}', 'a:4:{s:8:\"username\";s:8:\"Username\";s:5:\"email\";s:5:\"Email\";s:5:\"phone\";s:5:\"Phone\";s:7:\"id_card\";s:18:\"Identification No.\";}', 'a:4:{s:8:\"username\";s:27:\"ຊື່ຜູ້ໃຊ້\";s:5:\"email\";s:15:\"ອີເມວ\";s:5:\"phone\";s:30:\"ເບີໂທລະສັບ\";s:7:\"id_card\";s:39:\"ເລກບັດປະຈຳຕົວ\";}'),
(39, 'MAIL_PROGRAMS', 'array', 'index', 0, 'a:3:{i:0;s:43:\"ส่งจดหมายด้วย PHP\";i:1;s:72:\"ส่งจดหมายด้วย PHPMailer+SMTP (แนะนำ)\";i:2;s:58:\"ส่งจดหมายด้วย PHPMailer+PHP Mail\";}', 'a:3:{i:0;s:13:\"Send with PHP\";i:1;s:38:\"Send with PHPMailer+SMTP (recommended)\";i:2;s:28:\"Send with PHPMailer+PHP Mail\";}', 'a:3:{i:0;s:46:\"ສົ່ງຈົດໝາຍດ້ວຍ PHP\";i:1;s:75:\"ສົ່ງຈົດໝາຍດ້ວຍ PHPMailer+SMTP (ແນະນຳ)\";i:2;s:61:\"ສົ່ງຈົດໝາຍດ້ວຍ PHPMailer+PHP Mail\";}'),
(40, 'MONTH_LONG', 'array', 'index', 0, 'a:12:{i:1;s:18:\"มกราคม\";i:2;s:30:\"กุมภาพันธ์\";i:3;s:18:\"มีนาคม\";i:4;s:18:\"เมษายน\";i:5;s:21:\"พฤษภาคม\";i:6;s:24:\"มิถุนายน\";i:7;s:21:\"กรกฎาคม\";i:8;s:21:\"สิงหาคม\";i:9;s:21:\"กันยายน\";i:10;s:18:\"ตุลาคม\";i:11;s:27:\"พฤศจิกายน\";i:12;s:21:\"ธันวาคม\";}', 'a:12:{i:1;s:7:\"January\";i:2;s:8:\"February\";i:3;s:5:\"March\";i:4;s:5:\"April\";i:5;s:3:\"May\";i:6;s:4:\"June\";i:7;s:4:\"July\";i:8;s:6:\"August\";i:9;s:9:\"September\";i:10;s:7:\"October\";i:11;s:8:\"November\";i:12;s:8:\"December\";}', 'a:12:{i:1;s:18:\"ມັງກອນ\";i:2;s:15:\"ກຸມພາ\";i:3;s:12:\"ມີນາ\";i:4;s:12:\"ເມສາ\";i:5;s:21:\"ພຶດສະພາ\";i:6;s:18:\"ມິຖຸນາ\";i:7;s:21:\"ກໍລະກົດ\";i:8;s:15:\"ສິງຫາ\";i:9;s:15:\"ກັນຍາ\";i:10;s:12:\"ຕຸລາ\";i:11;s:15:\"ພະຈິກ\";i:12;s:15:\"ທັນວາ\";}'),
(41, 'MONTH_SHORT', 'array', 'index', 0, 'a:12:{i:1;s:8:\"ม.ค.\";i:2;s:8:\"ก.พ.\";i:3;s:11:\"มี.ค.\";i:4;s:11:\"เม.ย.\";i:5;s:8:\"พ.ค.\";i:6;s:11:\"มิ.ย.\";i:7;s:8:\"ก.ค.\";i:8;s:8:\"ส.ค.\";i:9;s:8:\"ก.ย.\";i:10;s:8:\"ต.ค.\";i:11;s:8:\"พ.ย.\";i:12;s:8:\"ธ.ค.\";}', 'a:12:{i:1;s:3:\"Jan\";i:2;s:3:\"Feb\";i:3;s:3:\"Mar\";i:4;s:3:\"Apr\";i:5;s:3:\"May\";i:6;s:3:\"Jun\";i:7;s:3:\"Jul\";i:8;s:3:\"Aug\";i:9;s:3:\"Sep\";i:10;s:3:\"Oct\";i:11;s:3:\"Nov\";i:12;s:3:\"Dec\";}', 'a:12:{i:1;s:8:\"ມ.ກ.\";i:2;s:8:\"ກ.ພ.\";i:3;s:11:\"ມີ.ນ.\";i:4;s:11:\"ເມ.ສ.\";i:5;s:8:\"ພ.ພ.\";i:6;s:11:\"ມິ.ນ.\";i:7;s:8:\"ກ.ກ.\";i:8;s:8:\"ສ.ຫ.\";i:9;s:8:\"ກ.ຍ.\";i:10;s:8:\"ຕ.ລ.\";i:11;s:8:\"ພ.ຈ.\";i:12;s:8:\"ທ.ວ.\";}'),
(42, 'Name', 'text', 'index', 0, 'ชื่อ นามสกุล', 'Name Surname', 'ຊື່ ນາມສະກຸນ'),
(43, 'PERMISSIONS', 'array', 'index', 0, 'a:2:{s:10:\"can_config\";s:60:\"สามารถตั้งค่าระบบได้\";s:22:\"can_view_usage_history\";s:93:\"สามารถดูประวัติการใช้งานระบบได้\";}', 'a:2:{s:10:\"can_config\";s:24:\"Can configure the system\";s:22:\"can_view_usage_history\";s:33:\"Able to view system usage history\";}', 'a:2:{s:10:\"can_config\";s:60:\"ສາມາດຕັ້ງຄ່າລະບົບໄດ້\";s:22:\"can_view_usage_history\";s:90:\"ສາມາດເບິ່ງປະຫວັດການນໍາໃຊ້ລະບົບ\";}'),
(44, 'PUBLISHEDS', 'array', 'index', 0, 'a:2:{i:0;s:45:\"ระงับการเผยแพร่\";i:1;s:21:\"เผยแพร่\";}', 'a:2:{i:0;s:11:\"Unpublished\";i:1;s:9:\"Published\";}', 'a:2:{i:0;s:45:\"ລະງັບການເຜີຍແຜ່\";i:1;s:21:\"ເຜີຍແຜ່\";}'),
(45, 'ROOM_CUSTOM_TEXT', 'array', 'index', 0, 'a:3:{s:8:\"building\";s:37:\"อาคาร/สถานที่\";s:6:\"number\";s:30:\"เลขที่ห้อง\";s:5:\"seats\";s:36:\"จำนวนที่นั่ง\";}', 'a:3:{s:8:\"building\";s:8:\"Building\";s:6:\"number\";s:8:\"Room No.\";s:5:\"seats\";s:15:\"Number of seats\";}', 'a:3:{s:8:\"building\";s:40:\"ອາຄານ/ສະຖານທີ່\";s:6:\"number\";s:12:\"ຫ້ອງ\";s:5:\"seats\";s:42:\"ຈໍານວນບ່ອນນັ່ງ\";}'),
(46, 'SEXES', 'array', 'index', 0, 'a:3:{s:1:\"u\";s:21:\"ไม่ระบุ\";s:1:\"f\";s:12:\"หญิง\";s:1:\"m\";s:9:\"ชาย\";}', 'a:3:{s:1:\"u\";s:13:\"Not specified\";s:1:\"f\";s:6:\"Female\";s:1:\"m\";s:4:\"Male\";}', 'a:3:{s:1:\"u\";s:30:\"ບໍ່ໄດ້ລະບຸ\";s:1:\"f\";s:9:\"ຍິງ\";s:1:\"m\";s:9:\"ຊາຍ\";}'),
(47, 'SMTPSECURIES', 'array', 'index', 0, 'a:2:{s:0:\"\";s:57:\"การเชื่อมต่อแบบปกติ\";s:3:\"ssl\";s:72:\"การเชื่อมต่อที่ปลอดภัย (SSL)\";}', 'a:2:{s:0:\"\";s:10:\"Clear Text\";s:3:\"ssl\";s:38:\"Server using a secure connection (SSL)\";}', 'a:2:{s:0:\"\";s:66:\"ການເຊື່ອມຕໍ່ແບບປົກກະຕິ\";s:3:\"ssl\";s:66:\"ການເຊື່ອມຕໍ່ທີ່ປອດໄຟ (SSL)\";}'),
(48, 'THEME_WIDTH', 'array', 'index', 0, 'a:3:{s:7:\"default\";s:33:\"ค่าเริ่มต้น\";s:4:\"wide\";s:15:\"กว้าง\";s:9:\"fullwidth\";s:30:\"กว้างพิเศษ\";}', 'a:3:{s:7:\"default\";s:7:\"Default\";s:4:\"wide\";s:4:\"Wide\";s:9:\"fullwidth\";s:10:\"Extra wide\";}', 'a:3:{s:7:\"default\";s:36:\"ຄ່າເລີ່ມຕົ້ນ\";s:4:\"wide\";s:15:\"ກວ້າງ\";s:9:\"fullwidth\";s:30:\"ກວ້າງພິເສດ\";}'),
(49, 'TIME_FORMAT', 'text', 'index', 0, 'H:i น.', 'H:i', 'H:i'),
(50, 'YEAR_OFFSET', 'int', 'index', 0, '543', '0', '0'),
(51, '0.0.0.0 mean all IP addresses', 'text', 'index', 0, '0.0.0.0 หมายถึงอนุญาตทั้งหมด', NULL, '0.0.0.0 ຫມາຍຄວາມວ່າອະນຸຍາດໃຫ້ທັງຫມົດ'),
(52, 'Accept all', 'text', 'index', 0, 'ยอมรับทั้งหมด', NULL, 'ຍອມຮັບທັງຫມົດ'),
(53, 'Accept this agreement', 'text', 'index', 0, 'ยอมรับข้อตกลง', NULL, 'ຍອມຮັບຂໍ້ຕົກລົງ'),
(54, 'Add', 'text', 'index', 0, 'เพิ่ม', NULL, 'ເພີ່ມ'),
(55, 'Add friend', 'text', 'index', 0, 'เพิ่มเพื่อน', NULL, 'ເພີ່ມເພື່ອນ'),
(56, 'Address', 'text', 'index', 0, 'ที่อยู่', NULL, 'ທີ່ຢູ່'),
(57, 'Address details', 'text', 'index', 0, 'รายละเอียดที่อยู่', NULL, 'ລາຍລະອຽດທີ່ຢູ່'),
(58, 'Administrator status It is of utmost importance to do everything', 'text', 'index', 0, 'สถานะผู้ดูแลระบบ มีความสำคัญสูงสุดสามารถทำได้ทุกอย่าง', NULL, 'ສະຖານະຜູ້ເບິ່ງແຍງລະບົບມີຄວາມສຳຄັນສຸງທີ່ສຸດສາມາດເຮັດໄດ້ທຸກຢ່າງ'),
(59, 'All :count entries, displayed :start to :end, page :page of :total pages', 'text', 'index', 0, 'ทั้งหมด :count รายการ, แสดง :start ถึง :end, หน้าที่ :page จากทั้งหมด :total หน้า', NULL, 'ທັງໝົດ :count ລາຍການ, ສະແດງ :start ເຖິງ :end, ໜ້າທີ່ :page ຈາກທັງໝົດ:total ໜ້າ'),
(60, 'all items', 'text', 'index', 0, 'ทั้งหมด', NULL, 'ທັງໝົດ'),
(61, 'All rooms', 'text', 'index', 0, 'ห้องทั้งหมด', NULL, 'ຫ້ອງທັງຫມົດ'),
(62, 'Always enabled', 'text', 'index', 0, 'เปิดใช้งานตลอดเวลา', NULL, 'ເປີດສະເໝີ'),
(63, 'API settings', 'text', 'index', 0, 'ตั้งค่า API', NULL, 'ຕັ້ງຄ່າ API'),
(64, 'Approval date', 'text', 'index', 0, 'วันที่ดำเนินการ', NULL, 'ວັນທີປະຕິບັດ'),
(65, 'Approve', 'text', 'index', 0, 'อนุมัติ', NULL, 'ອະນຸມັດ'),
(66, 'Approver', 'text', 'index', 0, 'ผู้ดำเนินการ', NULL, 'ຜູ້ປະຕິບັດ'),
(67, 'Approving/editing reservations', 'text', 'index', 0, 'การอนุมัติ/แก้ไข การจอง', NULL, 'ການອະນຸມັດ/ແກ້ໄຂການຈອງ'),
(68, 'Attached file', 'text', 'index', 0, 'ไฟล์แนบ', NULL, 'ໄຟລ໌ແນບ'),
(69, 'Attendees number', 'text', 'index', 0, 'จำนวนผู้เข้าร่วม', NULL, 'ຈໍານວນຜູ້ເຂົ້າຮ່ວມ'),
(70, 'Authentication require', 'text', 'index', 0, 'การตรวจสอบความถูกต้อง', NULL, 'ການກວດກາຄວາມຖືກຕ້ອງ'),
(71, 'Avatar', 'text', 'index', 0, 'รูปสมาชิก', NULL, 'ຮູບແທນຕົວ'),
(72, 'Background color', 'text', 'index', 0, 'สีพื้นหลัง', NULL, 'ສີພື້ນຫຼັງ'),
(73, 'Background image', 'text', 'index', 0, 'รูปภาพพื้นหลัง', NULL, 'ພາບພື້ນຫລັງ'),
(74, 'Begin date', 'text', 'index', 0, 'วันที่เริ่มต้น', NULL, 'ວັນເລີ່ມຕົ້ນ'),
(75, 'Begin time', 'text', 'index', 0, 'เวลาเริ่มต้น', NULL, 'ເລີ່ມເວລາ'),
(76, 'Book a room', 'text', 'index', 0, 'จองห้อง', NULL, 'ຈອງຫ້ອງ'),
(77, 'Booking', 'text', 'index', 0, 'การจอง', NULL, 'ການຈອງ'),
(78, 'Booking are not available at select time', 'text', 'index', 0, 'ไม่สามารถใช้งานได้ในเวลาที่เลือก', NULL, 'ບໍ່ມີເວລາທີ່ເລືອກ.'),
(79, 'Booking calendar', 'text', 'index', 0, 'ปฏิทินการจอง', NULL, 'ປະຕິທິນການຈອງ'),
(80, 'Booking date', 'text', 'index', 0, 'วันที่จอง', NULL, 'ວັນທີຈອງ'),
(81, 'Booking today', 'text', 'index', 0, 'การจองวันนี้', NULL, 'ຈອງໃນມື້ນີ້'),
(82, 'Browse file', 'text', 'index', 0, 'เลือกไฟล์', NULL, 'ເລືອກໄຟລ໌'),
(83, 'Browse image uploaded, type :type', 'text', 'index', 0, 'เลือกรูปภาพอัปโหลด ชนิด :type', NULL, 'ເລືອກຮູບພາບອັບໂຫຼດຊະນິດ :type'),
(84, 'Can be approve', 'text', 'index', 0, 'สามารถอนุมัติได้', NULL, 'ສາມາດອະນຸມັດ'),
(85, 'Can login', 'text', 'index', 0, 'สามารถเข้าระบบได้', NULL, 'ສາມາດເຂົ້າສູ່ລະບົບ'),
(86, 'Can manage the', 'text', 'index', 0, 'สามารถจัดการ', NULL, 'ສາມາດຈັດການ'),
(87, 'Can not be performed this request. Because they do not find the information you need or you are not allowed', 'text', 'index', 0, 'ไม่สามารถดำเนินการตามที่ร้องขอได้ เนื่องจากไม่พบข้อมูลที่ต้องการ หรือ คุณไม่มีสิทธิ์', NULL, 'ບໍ່ສາມາດດຳເນີນການຕາມທີ່ຮ້ອງຂໍໄດ້ເນື່ອງຈາກບໍ່ພົບຂໍ້ມູນທີ່ຕ້ອງການ ຫຼື ທ່ານບໍ່ມີສິດ'),
(88, 'Can&#039;t login', 'text', 'index', 0, 'ไม่สามารถเข้าระบบได้', NULL, 'ບໍ່ສາມາດເຂົ້າສູ່ລະບົບໄດ້'),
(89, 'Cancel', 'text', 'index', 0, 'ยกเลิก', NULL, 'ຍົກເລີກ'),
(90, 'Canceled successfully', 'text', 'index', 0, 'ยกเลิกเรียบร้อย', NULL, 'ຍົກເລີກສົບຜົນສໍາເລັດ'),
(91, 'Cancellation', 'text', 'index', 0, 'การยกเลิก', NULL, 'ການຍົກເລີກ'),
(92, 'Change language', 'text', 'index', 0, 'สลับภาษา', NULL, 'ປ່ຽນພາສາ'),
(93, 'Click to edit', 'text', 'index', 0, 'คลิกเพื่อแก้ไข', NULL, 'ກົດເພື່ອແກ້ໄຂ'),
(94, 'Color', 'text', 'index', 0, 'สี', NULL, 'ສີ'),
(95, 'Confirm password', 'text', 'index', 0, 'ยืนยันรหัสผ่าน', NULL, 'ຢືນຢັນລະຫັດຜ່ານ'),
(96, 'Congratulations, your email address has been verified. please login', 'text', 'index', 0, 'ยินดีด้วย ที่อยู่อีเมลของคุณได้รับการยืนยันเรียบร้อยแล้ว กรุณาเข้าสู่ระบบ', NULL, 'ຂໍສະແດງຄວາມຍິນດີ, ທີ່ຢູ່ອີເມວຂອງທ່ານໄດ້ຮັບການຢັ້ງຢືນແລ້ວ. ກະລຸນາເຂົ້າສູ່ລະບົບ'),
(97, 'Contact name', 'text', 'index', 0, 'ชื่อผู้จอง', NULL, 'ຕົວແທນການຈອງ'),
(98, 'Cookie Policy', 'text', 'index', 0, 'นโยบายคุกกี้', NULL, 'ນະໂຍບາຍຄຸກກີ'),
(99, 'COOKIE_NECESSARY_DETAILS', 'text', 'index', 0, 'คุกกี้พื้นฐาน จำเป็นต่อการใช้งานเว็บไซต์ ใช้เพื่อการรักษาความปลอดภัยและให้เว็บไซต์สามารถทำงานได้อย่างถูกต้อง', NULL, 'ຄຸກກີພື້ນຖານ ມີຄວາມຈໍາເປັນໃນການນໍາໃຊ້ເວັບໄຊທ໌ ມັນຖືກນໍາໃຊ້ເພື່ອຈຸດປະສົງຄວາມປອດໄພແລະເພື່ອໃຫ້ເວັບໄຊທ໌ເຮັດວຽກຢ່າງຖືກຕ້ອງ.'),
(100, 'COOKIE_POLICY_DETAILS', 'text', 'index', 0, 'เราใช้คุกกี้ (Cookies) หรือเทคโนโลยีที่คล้ายคลึงกันเท่าที่จำเป็น เพื่อใช้ในการเข้าถึงสินค้าหรือบริการ และติดตามการใช้งานของคุณเท่านั้น หากคุณไม่ต้องการให้มีคุกกี้ไว้ในคอมพิวเตอร์ของคุณ คุณสามารถตั้งค่าบราวเซอร์เพื่อปฏิเสธการจัดเก็บคุกกี้ก่อนที่จะใช้งานเว็บไซต์ หรือใช้โหมดไม่ระบุตัวตนเพื่อเข้าใช้งานเว็บไซต์ก็ได้', NULL, 'ພວກເຮົາໃຊ້ຄຸກກີ (Cookies) ຫຼືເຕັກໂນໂລຢີທີ່ຄ້າຍຄືກັນໃນຂອບເຂດທີ່ຈໍາເປັນ. ສໍາລັບການນໍາໃຊ້ໃນການເຂົ້າເຖິງສິນຄ້າຫຼືການບໍລິການ ແລະພຽງແຕ່ຕິດຕາມການນໍາໃຊ້ຂອງທ່ານ ຖ້າ​ຫາກ​ວ່າ​ທ່ານ​ບໍ່​ຕ້ອງ​ການ cookies ໃນ​ຄອມ​ພິວ​ເຕີ​ຂອງ​ທ່ານ​ ທ່ານສາມາດຕັ້ງຕົວທ່ອງເວັບຂອງທ່ານເພື່ອປະຕິເສດການເກັບຮັກສາ cookies. ກ່ອນທີ່ຈະນໍາໃຊ້ເວັບໄຊທ໌ ທ່ານຍັງສາມາດໃຊ້ໂໝດບໍ່ເປີດເຜີຍຕົວຕົນເພື່ອເຂົ້າຫາເວັບໄຊທ໌ໄດ້.'),
(101, 'Country', 'text', 'index', 0, 'ประเทศ', NULL, 'ປະເທດ'),
(102, 'Create', 'text', 'index', 0, 'สร้าง', NULL, 'ສ້າງ'),
(103, 'Create new account', 'text', 'index', 0, 'สร้างบัญชีใหม่', NULL, 'ສ້າງບັນຊີໃໝ່'),
(104, 'Created', 'text', 'index', 0, 'สร้างเมื่อ', NULL, 'ສ້າງເມື່ອ'),
(105, 'Currency unit', 'text', 'index', 0, 'สกุลเงิน', NULL, 'ສະກຸນເງິນ'),
(106, 'Data controller', 'text', 'index', 0, 'ผู้ควบคุม/ใช้ ข้อมูล', NULL, 'ຜູ້​ຄວບ​ຄຸມຂໍ້ມູນ'),
(107, 'Date', 'text', 'index', 0, 'วันที่', NULL, 'ວັນທີ'),
(108, 'days', 'text', 'index', 0, 'วัน', NULL, 'ມື້'),
(109, 'Delete', 'text', 'index', 0, 'ลบ', NULL, 'ລືບ'),
(110, 'Delete items that have been canceled by the booker', 'text', 'index', 0, 'ลบรายการที่ถูกยกเลิกโดยผู้จอง', NULL, 'ລຶບລາຍການທີ່ຖືກຍົກເລີກໂດຍຜູ້ຈອງ'),
(111, 'Demo Mode', 'text', 'index', 0, 'โหมดตัวอย่าง', NULL, 'ຕົວຢ່າງ'),
(112, 'Description', 'text', 'index', 0, 'คำอธิบาย', NULL, 'ຄຳອະທິບາຍ'),
(113, 'Detail', 'text', 'index', 0, 'รายละเอียด', NULL, 'ລາຍະລະອຽດ'),
(114, 'Details of', 'text', 'index', 0, 'รายละเอียดของ', NULL, 'ລາຍລະອຽດຂອງ'),
(115, 'Download', 'text', 'index', 0, 'ดาวน์โหลด', NULL, 'ດາວໂຫຼດ'),
(116, 'Drag and drop to reorder', 'text', 'index', 0, 'ลากและวางเพื่อจัดลำดับใหม่', NULL, 'ລາກແລ້ວວາງລົງເພື່ອຈັດຮຽງໃໝ່'),
(117, 'Edit', 'text', 'index', 0, 'แก้ไข', NULL, 'ແກ້ໄຂ'),
(118, 'Editing your account', 'text', 'index', 0, 'แก้ไขข้อมูลส่วนตัว', NULL, 'ແກ້ໄຂຂໍ້ມູນສ່ວນຕົວສະມາຊິກ'),
(119, 'Email', 'text', 'index', 0, 'อีเมล', NULL, 'ອີເມວ'),
(120, 'Email address used for login or request a new password', 'text', 'index', 0, 'ที่อยู่อีเมล ใช้สำหรับการเข้าระบบหรือการขอรหัสผ่านใหม่', NULL, 'ທີ່ຢູ່ອີເມວໃຊ້ສຳລັບການເຂົ້າລະບົບຫຼືການຂໍລະຫັດໃໝ່'),
(121, 'Email address verification', 'text', 'index', 0, 'ยืนยันที่อยู่อีเมล', NULL, 'ຢືນຢັນທີ່ຢູ່ອີເມວ'),
(122, 'Email addresses for sender and do not reply such as no-reply@domain.tld', 'text', 'index', 0, 'ทีอยู่อีเมลใช้เป็นผู้ส่งจดหมาย สำหรับจดหมายที่ไม่ต้องการตอบกลับ เช่น no-reply@domain.tld', NULL, 'ທີ່ຢູ່ອີເມວໃຊ້ເປັນຜູ້ສົ່ງຈົດໝາຍ ສຳລັບຈົດໝາຍທີ່ບໍ່ຕ້ອງການຕອບກັບເຊັ່ນ no-reply@domain.tld'),
(123, 'Email encoding', 'text', 'index', 0, 'รหัสภาษาของจดหมาย', NULL, 'ລະຫັດພາສາຂອງຈົດໝາຍ'),
(124, 'Email settings', 'text', 'index', 0, 'ตั้งค่าอีเมล', NULL, 'ຕັ້ງຄ່າອີເມວ'),
(125, 'Email the relevant person', 'text', 'index', 0, 'ส่งอีเมลแจ้งผู้ที่เกี่ยวข้องด้วย', NULL, 'ສົ່ງອີເມວຫາບຸກຄົນທີ່ກ່ຽວຂ້ອງ.'),
(126, 'Email was not verified', 'text', 'index', 0, 'ยังไม่ได้ยืนยันอีเมล', NULL, 'ອີເມວບໍ່ໄດ້ຖືກຢືນຢັນ'),
(127, 'Enable SSL encryption for sending email', 'text', 'index', 0, 'เปิดใช้งานการเข้ารหัส SSL สำหรับการส่งอีเมล', NULL, 'ເປີດໃຊ້ການເຂົ້າລະຫັດ SSL ສຳລັບການສົ່ງອີເມວ'),
(128, 'End date', 'text', 'index', 0, 'วันที่สิ้นสุด', NULL, 'ວັນສິ້ນສຸດ'),
(129, 'End date must be greater than begin date', 'text', 'index', 0, 'วันที่สิ้นสุดต้องมากกว่าวันที่เริ่มต้น', NULL, 'ວັນສິ້ນສຸດຕ້ອງຫຼາຍກວ່າວັນທີເລີ່ມຕົ້ນ.'),
(130, 'End time', 'text', 'index', 0, 'เวลาสิ้นสุด', NULL, 'ເວລາສິ້ນສຸດ'),
(131, 'English lowercase letters and numbers, not less than 6 digits', 'text', 'index', 0, 'ภาษาอังกฤษตัวพิมพ์เล็กและตัวเลข ไม่น้อยกว่า 6 หลัก', NULL, 'ໂຕພິມນ້ອຍພາສາອັງກິດ ແລະຕົວເລກ, ບໍ່ຕໍ່າກວ່າ 6 ຕົວເລກ'),
(132, 'Enter the domain name you want to allow or enter * for all domains. or leave it blank if you want to use it on this domain only', 'text', 'index', 0, 'กรอกชื่อโดเมนที่ต้องการอนุญาต หรือกรอก * สำหรับทุกโดเมน หรือเว้นว่างไว้ถ้าต้องการให้ใช้งานได้บนโดเมนนี้เท่านั้น', NULL, 'ໃສ່ຊື່ໂດເມນທີ່ທ່ານຕ້ອງການທີ່ຈະອະນຸຍາດໃຫ້ຫຼືໃສ່ * ສໍາລັບໂດເມນທັງຫມົດ. ຫຼືປ່ອຍໃຫ້ມັນຫວ່າງຖ້າທ່ານຕ້ອງການໃຊ້ມັນຢູ່ໃນໂດເມນນີ້ເທົ່ານັ້ນ'),
(133, 'Enter the email address registered. A new password will be sent to this email address.', 'text', 'index', 0, 'กรอกที่อยู่อีเมลที่ลงทะเบียนไว้ ระบบจะส่งรหัสผ่านใหม่ไปยังที่อยู่อีเมลนี้', NULL, 'ເພີ່ມທີ່ຢູ່ອີເມວທີ່ລົງທະບຽນໄວ້ ລະບົບຈະສົ່ງລະຫັດຜ່ານໃໝ່ໄປຍັງທີ່ຢູ່ອີເມວນີ້'),
(134, 'Enter the LINE user ID you received when adding friends. Or type userId sent to the official account to request a new user ID. This information is used for receiving private messages from the system via LINE.', 'text', 'index', 0, 'กรอก user ID ของไลน์ที่ได้ตอนเพิ่มเพื่อน หรือพิมพ์คำว่า userId ส่งไปยังบัญชีทางการเพื่อขอ user ID ใหม่ ข้อมูลนี้ใช้สำหรับการรับข้อความส่วนตัวที่มาจากระบบผ่านไลน์', NULL, 'ໃສ່ user ID ຂອງ LINE ທີ່ທ່ານໄດ້ຮັບໃນເວລາເພີ່ມເພື່ອນ. ຫຼືພິມ userId ທີ່ຖືກສົ່ງໄປຫາບັນຊີທາງການເພື່ອຮ້ອງຂໍ user ID ໃຫມ່. ຂໍ້ມູນນີ້ແມ່ນໃຊ້ສໍາລັບການຮັບຂໍ້ຄວາມສ່ວນຕົວຈາກລະບົບຜ່ານ LINE.'),
(135, 'Enter your password again', 'text', 'index', 0, 'กรอกรหัสผ่านของคุณอีกครั้ง', NULL, 'ໃສ່ລະຫັດຜ່ານຂອງທ່ານອີກຄັ້ງ'),
(136, 'entries', 'text', 'index', 0, 'รายการ', NULL, 'ລາຍການ'),
(137, 'Expiration date', 'text', 'index', 0, 'วันหมดอายุ', NULL, 'ວັນໝົດອາຍຸ'),
(138, 'Fax', 'text', 'index', 0, 'โทรสาร', NULL, 'ແຟັກ'),
(139, 'File', 'text', 'index', 0, 'ไฟล์', NULL, 'ແຟ້ມ'),
(140, 'Footer', 'text', 'index', 0, 'ส่วนท้าย', NULL, 'ສ່ວນທ້າຍ'),
(141, 'for login by LINE account', 'text', 'index', 0, 'สำหรับการเข้าระบบโดยบัญชีไลน์', NULL, 'ສໍາລັບການເຂົ້າສູ່ລະບົບດ້ວຍບັນຊີ LINE'),
(142, 'Forgot', 'text', 'index', 0, 'ลืมรหัสผ่าน', NULL, 'ລືມລະຫັດຜ່ານ'),
(143, 'from', 'text', 'index', 0, 'จาก', NULL, 'ຈາກ'),
(144, 'General', 'text', 'index', 0, 'ทั่วไป', NULL, 'ທົ່ວໄປ'),
(145, 'General site settings', 'text', 'index', 0, 'ตั้งค่าพื้นฐานของเว็บไซต์', NULL, 'ຕັ້ງຄ່າພື້ນຖານຂອງເວັບໄຊ'),
(146, 'Get new password', 'text', 'index', 0, 'ขอรหัสผ่าน', NULL, 'ຂໍລະຫັດຜ່ານ'),
(147, 'go to page', 'text', 'index', 0, 'ไปหน้าที่', NULL, 'ໄປທີ່ໜ້າ'),
(148, 'Header', 'text', 'index', 0, 'ส่วนหัว', NULL, 'ສ່ວນຫົວ'),
(149, 'Home', 'text', 'index', 0, 'หน้าหลัก', NULL, 'ໜ້າຫຼັກ'),
(150, 'How to define user authentication for mail servers. If you enable it, you must configure below correctly.', 'text', 'index', 0, 'กำหนดวิธีการตรวจสอบผู้ใช้สำหรับเมล์เซิร์ฟเวอร์ หากคุณเปิดใช้งานคุณต้องกำหนดค่าต่างๆด้านล่างถูกต้อง', NULL, 'ກຳນົດວິທີການກວດສອບຜູ້ໃຊ້ສຳລັບເມນເຊິບເວີຫາກທ່ານເປີດໃຊ້ການທ່ານຕ້ອງກຳນົດຄ່າຕ່າງໆດ້ານລຸ່ມຖືກຕ້ອງ'),
(151, 'Identification No.', 'text', 'index', 0, 'รหัสนักศึกษา', NULL, ''),
(152, 'Image', 'text', 'index', 0, 'รูปภาพ', NULL, 'ຮູບພາບ'),
(153, 'Image size is in pixels', 'text', 'index', 0, 'ขนาดของรูปภาพเป็นพิกเซล', NULL, 'ຂະໜາດຂອງຮູບພາບເປັນພິກເຊວ'),
(154, 'Import', 'text', 'index', 0, 'นำเข้า', NULL, 'ນຳເຂົ້າ'),
(155, 'Initial booking status', 'text', 'index', 0, 'สถานะการจองเริ่มต้น', NULL, 'ສະຖານະການຈອງເບື້ອງຕົ້ນ'),
(156, 'Installed modules', 'text', 'index', 0, 'โมดูลที่ติดตั้งแล้ว', NULL, 'ໂມດູນທີ່ຕິດຕັ້ງ'),
(157, 'Invalid :name', 'text', 'index', 0, ':name ไม่ถูกต้อง', NULL, ':name ບໍ່ຖືກຕ້ອງ'),
(158, 'Key', 'text', 'index', 0, 'คีย์', NULL, 'ແປ້ນພີມ'),
(159, 'Language', 'text', 'index', 0, 'ภาษา', NULL, 'ພາສາ'),
(160, 'LINE official account (with @ prefix, e.g. @xxxx)', 'text', 'index', 0, 'บัญชีทางการของไลน์ (มี @ นำหน้า เช่น @xxxx)', NULL, 'ບັນຊີທາງການຂອງ LINE (ມີ @ ຄໍານໍາຫນ້າ, ເຊັ່ນ: @xxxx)'),
(161, 'LINE settings', 'text', 'index', 0, 'ตั้งค่าไลน์', NULL, 'ຕັ້ງ​ຄ່າ LINE'),
(162, 'List of', 'text', 'index', 0, 'รายการ', NULL, 'ລາຍການ'),
(163, 'List of IPs that allow connection 1 line per 1 IP', 'text', 'index', 0, 'รายการไอพีแอดเดรสทั้งหมดที่อนุญาต 1 บรรทัดต่อ 1 ไอพี', NULL, 'ລາຍຊື່ IP ທີ່ອະນຸຍາດໃຫ້ເຊື່ອມຕໍ່ 1 ເສັ້ນຕໍ່ 1 IP'),
(164, 'Local time', 'text', 'index', 0, 'เวลาท้องถิ่น', NULL, 'ເວລາທ້ອງຖິ່ນ'),
(165, 'Login', 'text', 'index', 0, 'เข้าสู่ระบบ', NULL, 'ເຂົ້າສູ່ລະບົບ'),
(166, 'Login as', 'text', 'index', 0, 'เข้าระบบเป็น', NULL, 'ເຂົ້າ​ສູ່​ລະ​ບົບ​ເປັນ'),
(167, 'Login by', 'text', 'index', 0, 'เข้าระบบโดย', NULL, 'ເຂົ້າສູ່ລະບົບໂດຍ'),
(168, 'Login information', 'text', 'index', 0, 'ข้อมูลการเข้าระบบ', NULL, 'ຂໍ້ມູນການເຂົ້າລະບົບ'),
(169, 'Login page', 'text', 'index', 0, 'หน้าเข้าสู่ระบบ', NULL, 'ໜ້າເຂົ້າສູ່ລະບົບ'),
(170, 'Login with an existing account', 'text', 'index', 0, 'เข้าระบบด้วยบัญชีสมาชิกที่มีอยู่แล้ว', NULL, 'ເຂົ້າລະບົບດ້ວຍບັນຊີສະມາຊິກທີ່ມີຢູ່ແລ້ວ'),
(171, 'Logo', 'text', 'index', 0, 'โลโก', NULL, 'ໂລໂກ'),
(172, 'Logout', 'text', 'index', 0, 'ออกจากระบบ', NULL, 'ອອກຈາກລະບົບ'),
(173, 'Logout successful', 'text', 'index', 0, 'ออกจากระบบเรียบร้อย', NULL, 'ອອກຈາກລະບົບຮຽບຮ້ອຍ'),
(174, 'Mail program', 'text', 'index', 0, 'โปรแกรมส่งอีเมล', NULL, 'ໂປຮແກຮມສົ່ງອີເມວ'),
(175, 'Mail server', 'text', 'index', 0, 'เซิร์ฟเวอร์อีเมล', NULL, 'ເຊີບເວີອີເມວ'),
(176, 'Mail server port number (default is 25, for GMail used 465, 587 for DirectAdmin).', 'text', 'index', 0, 'หมายเลขพอร์ตของเมล์เซิร์ฟเวอร์ (ค่าปกติคือ 25, สำหรับ gmail ใช้ 465, 587 สำหรับ DirectAdmin)', NULL, 'ໝາຍເລກພອດຂອງເມວເຊີບເວີ(ຄ່າປົກກະຕິຄື 25, ສຳລັບ gmail ໃຊ້ 465, 587 ສຳລັບ DirectAdmin)'),
(177, 'Mail server settings', 'text', 'index', 0, 'ค่ากำหนดของเมล์เซิร์ฟเวอร์', NULL, 'ຄ່າກຳນົດຂອງເມວເຊີບເວີ'),
(178, 'Manage languages', 'text', 'index', 0, 'จัดการภาษา', NULL, 'ຈັດການພາສາ'),
(179, 'Member list', 'text', 'index', 0, 'รายชื่อสมาชิก', NULL, 'ລາຍຊື່ສະມາຊິກ'),
(180, 'Member status', 'text', 'index', 0, 'สถานะสมาชิก', NULL, 'ສະຖານະສະມາຊິກ'),
(181, 'Message', 'text', 'index', 0, 'ข้อความ', NULL, 'ຂໍ້ຄວາມ'),
(182, 'Message displayed on login page', 'text', 'index', 0, 'ข้อความแสดงในหน้าเข้าสู่ระบบ', NULL, 'ຂໍ້ຄວາມສະແດງຢູ່ໃນຫນ້າເຂົ້າສູ່ລະບົບ'),
(183, 'Module', 'text', 'index', 0, 'โมดูล', NULL, 'ໂມດູນ'),
(184, 'Module settings', 'text', 'index', 0, 'ตั้งค่าโมดูล', NULL, 'ຕັ້ງຄ່າໂມດູນ'),
(185, 'month', 'text', 'index', 0, 'เดือน', NULL, 'ເດືອນ'),
(186, 'My Booking', 'text', 'index', 0, 'รายการจองของฉัน', NULL, 'ການຈອງຂອງຂ້ອຍ'),
(187, 'Necessary cookies', 'text', 'index', 0, 'คุกกี้พื้นฐานที่จำเป็น', NULL, 'ຄຸກກີພື້ນຖານທີ່ຈໍາເປັນ'),
(188, 'New members', 'text', 'index', 0, 'สมาชิกใหม่', NULL, 'ສະມາຊິກໃໝ່'),
(189, 'no larger than :size', 'text', 'index', 0, 'ขนาดไม่เกิน :size', NULL, 'ຂະໜາດບໍ່ເກີນ :size'),
(190, 'No need to fill in English text. If the English text matches the Key', 'text', 'index', 0, 'ไม่จำเป็นต้องกรอกข้อความในภาษาอังกฤษ หากข้อความในภาษาอังกฤษตรงกับคีย์', NULL, 'ບໍ່ຈຳເປັນເພີ່ມຂໍ້ຄວາມໃນພາສາອັງກິດຫາກຂໍ້ຄວາມໃນພາສານອັງກົງກັບແປ້ນພີມ'),
(191, 'not a registered user', 'text', 'index', 0, 'ไม่พบสมาชิกนี้ลงทะเบียนไว้', NULL, 'ບໍ່ພົບສະມາຊິກນີ້ລົງທະບຽນໄວ້'),
(192, 'Notification', 'text', 'index', 0, 'การแจ้งเตือน', NULL, 'ຄໍາປະກາດ'),
(193, 'Notify relevant parties when booking details are modified by customers', 'text', 'index', 0, 'แจ้งเตือนไปยังผู้ที่เกี่ยวข้องเมื่อมีการแก้ไขรายละเอียดการจองโดยผู้จอง', NULL, 'ແຈ້ງໃຫ້ພາກສ່ວນທີ່ກ່ຽວຂ້ອງຊາບໃນເວລາທີ່ລາຍລະອຽດການຈອງຖືກດັດແກ້ໂດຍລູກຄ້າ'),
(194, 'Other', 'text', 'index', 0, 'อื่นๆ', NULL, 'ອື່ນໆ'),
(195, 'Page details', 'text', 'index', 0, 'รายละเอียดของหน้า', NULL, 'ລາຍລະອຽດຂອງໜ້າ'),
(196, 'Password', 'text', 'index', 0, 'รหัสผ่าน', NULL, 'ລະຫັດຜ່ານ'),
(197, 'Password of the mail server. (To change the fill.)', 'text', 'index', 0, 'รหัสผ่านของเมล์เซิร์ฟเวอร์ (ต้องการเปลี่ยน ให้กรอก)', NULL, 'ລະຫັດຜ່ານຂອງເມວເຊີບເວີ (ຕ້ອງການປ່ຽນ ໃຫ້ເພີ່ມ)'),
(198, 'Passwords must be at least four characters', 'text', 'index', 0, 'รหัสผ่านต้องไม่น้อยกว่า 4 ตัวอักษร', NULL, 'ລະຫັດຜ່ານຕ້ອງບໍ່ຕ່ຳກວ່າ 4 ຕົວອັກສອນ'),
(199, 'Permission', 'text', 'index', 0, 'สิทธิ์การใช้งาน', NULL, 'ສິດໃນການໃຊ້ວຽກ'),
(200, 'Phone', 'text', 'index', 0, 'โทรศัพท์', NULL, 'ເບີໂທລະສັບ'),
(201, 'Please check the new member registration.', 'text', 'index', 0, 'กรุณาตรวจสอบการลงทะเบียนสมาชิกใหม่', NULL, 'ກະລຸນາກວດສອບການລົງທະບຽນສະມາຊິກໃໝ່.'),
(202, 'Please click the link to verify your email address.', 'text', 'index', 0, 'กรุณาคลิกลิงค์เพื่อยืนยันที่อยู่อีเมล', NULL, 'ກະລຸນາຄລິກທີ່ລິ້ງເພື່ອຢືນຢັນທີ່ຢູ່ອີເມວຂອງທ່ານ'),
(203, 'Please fill in', 'text', 'index', 0, 'กรุณากรอก', NULL, 'ກະລຸນາຕື່ມຂໍ້ມູນໃສ່'),
(204, 'Please fill up this form', 'text', 'index', 0, 'กรุณากรอกแบบฟอร์มนี้', NULL, 'ກະລຸນາຕື່ມແບບຟອມນີ້'),
(205, 'Please log in to continue', 'text', 'index', 0, 'กรุณาเข้าระบบ ก่อนดำเนินการต่อ', NULL, 'ກະລຸນາເຂົ້າລະບົບ ກ່ອນທີ່ຈະດຳເນີນການ'),
(206, 'Please login', 'text', 'index', 0, 'กรุณาเข้าระบบ', NULL, 'ກະລຸນາເຂົ້າສູ່ລະບົບ'),
(207, 'Please select', 'text', 'index', 0, 'กรุณาเลือก', NULL, 'ກະລຸນາເລືອກ'),
(208, 'Please select :name at least one item', 'text', 'index', 0, 'กรุณาเลือก :name อย่างน้อย 1 รายการ', NULL, 'ກະລຸນາເລືອກ :name ຢ່າງໜ້ອຍ 1 ລາຍການ'),
(209, 'Port', 'text', 'index', 0, 'พอร์ต', NULL, 'ພອດ'),
(210, 'Privacy Policy', 'text', 'index', 0, 'นโยบายความเป็นส่วนตัว', NULL, 'ນະໂຍບາຍຄວາມເປັນສ່ວນຕົວ'),
(211, 'Profile', 'text', 'index', 0, 'ข้อมูลส่วนตัว', NULL, 'ຂໍ້ມູນສ່ວນຕົວ'),
(212, 'Province', 'text', 'index', 0, 'จังหวัด', NULL, 'ແຂວງ'),
(213, 'Reason', 'text', 'index', 0, 'เหตุผล', NULL, 'ເຫດ​ຜົນ'),
(214, 'Register', 'text', 'index', 0, 'สมัครสมาชิก', NULL, 'ສະໝັກສະມາຊິກ'),
(215, 'Register successfully Please log in', 'text', 'index', 0, 'ลงทะเบียนเรียบร้อยแล้วกรุณาเข้าสู่ระบบ', NULL, 'ລົງທະບຽນຢ່າງສຳເລັດຜົນກະລຸນາເຂົ້າສູ່ລະບົບ'),
(216, 'Register successfully, We have sent complete registration information to :email', 'text', 'index', 0, 'ลงทะเบียนสมาชิกใหม่เรียบร้อย เราได้ส่งข้อมูลการลงทะเบียนไปยัง :email', NULL, 'ລົງທະບຽນສຳເລັດແລ້ວ ເຮົາໄດ້ສົ່ງຂໍ້ມູນການລົງທະບຽນໄປທີ່ :email'),
(217, 'Registered successfully Please check your email :email and click the link to verify your email.', 'text', 'index', 0, 'ลงทะเบียนเรียบร้อย กรุณาตรวจสอบอีเมล์ :email และคลิงลิงค์ยืนยันอีเมล', NULL, 'ລົງທະບຽນສົບຜົນສໍາເລັດ ກະ​ລຸ​ນາ​ກວດ​ສອບ​ອີ​ເມວ​ຂອງ​ທ່ານ :email ແລະ​ຄລິກ​ໃສ່​ການ​ເຊື່ອມ​ຕໍ່​ເພື່ອ​ກວດ​ສອບ​ອີ​ເມວ​ຂອງ​ທ່ານ​.'),
(218, 'Remember me', 'text', 'index', 0, 'จำการเข้าระบบ', NULL, 'ຈົດຈຳການເຂົ້າລະບົບ'),
(219, 'Remove', 'text', 'index', 0, 'ลบ', NULL, 'ລຶບ'),
(220, 'Report', 'text', 'index', 0, 'รายงาน', NULL, 'ລາຍງານ'),
(221, 'resized automatically', 'text', 'index', 0, 'ปรับขนาดอัตโนมัติ', NULL, 'ປັບຂະໜາດອັດຕະໂນມັດ'),
(222, 'Room', 'text', 'index', 0, 'ห้อง', NULL, 'ຫ້ອງ'),
(223, 'Room name', 'text', 'index', 0, 'ชื่อห้อง', NULL, 'ຊື່ຫ້ອງ'),
(224, 'Room No.', 'text', 'index', 0, 'หมายเลขห้อง', NULL, 'ຫ້ອງຈໍານວນຫ້ອງ'),
(225, 'Save', 'text', 'index', 0, 'บันทึก', NULL, 'ບັນທຶກ'),
(226, 'Save and email completed', 'text', 'index', 0, 'บันทึกและส่งอีเมลเรียบร้อย', NULL, 'ບັນທຶກແລະສົ່ງອີເມວຮຽນຮ້ອຍ'),
(227, 'Saved successfully', 'text', 'index', 0, 'บันทึกเรียบร้อย', NULL, 'ບັນທຶກຮຽບຮ້ອຍ'),
(228, 'scroll to top', 'text', 'index', 0, 'เลื่อนขึ้นด้านบน', NULL, 'ເລື່ອນຂື້ນດ້ານເທິງ'),
(229, 'Search', 'text', 'index', 0, 'ค้นหา', NULL, 'ຄົ້ນຫາ'),
(230, 'Search <strong>:search</strong> found :count entries, displayed :start to :end, page :page of :total pages', 'text', 'index', 0, 'ค้นหา <strong>:search</strong> พบ :count รายการ แสดงรายการที่ :start - :end หน้าที่ :page จากทั้งหมด :total หน้า', NULL, 'ຄົ້ນຫາ <strong>:search</strong> ພົບ :count ລາຍການ ສະແດງລາຍການທີ່:start - :end ໜ້າທີ່:page ຈາກທັງໝົດ :total ໜ້າ'),
(231, 'Send a notification message to the person concerned', 'text', 'index', 0, 'ส่งข้อความแจ้งเตือนไปยังผู้ที่เกี่ยวข้องด้วย', NULL, 'ສົ່ງຂໍ້ຄວາມແຈ້ງເຕືອນໃຫ້ກັບບຸກຄົນທີ່ກ່ຽວຂ້ອງ'),
(232, 'Send a welcome email to new members', 'text', 'index', 0, 'ส่งข้อความต้อนรับสมาชิกใหม่', NULL, 'ສົ່ງອີເມວຕ້ອນຮັບກັບສະມາຊິກໃຫມ່'),
(233, 'Send login authorization email', 'text', 'index', 0, 'ส่งอีเมลอนุมัติการเข้าระบบ', NULL, 'ສົ່ງອີເມວການອະນຸຍາດເຂົ້າສູ່ລະບົບ'),
(234, 'Send member confirmation email', 'text', 'index', 0, 'ส่งอีเมลยืนยันสมาชิก', NULL, 'ສົ່ງອີເມລ໌ຢືນຢັນສະມາຊິກ'),
(235, 'send message to user When a user adds LINE&#039;s official account as a friend', 'text', 'index', 0, 'ส่งข้อความไปยังผู้ใช้ เมื่อผู้ใช้เพิ่มบัญชีทางการของไลน์เป็นเพื่อน', NULL, 'ສົ່ງຂໍ້ຄວາມຫາຜູ້ໃຊ້ ເມື່ອຜູ້ໃຊ້ເພີ່ມບັນຊີທາງການຂອງ LINE ເປັນໝູ່'),
(236, 'Send notification messages When making a transaction', 'text', 'index', 0, 'ส่งข้อความแจ้งเตือนเมื่อมีการทำรายการ', NULL, 'ສົ່ງຂໍ້ຄວາມແຈ້ງເຕືອນເມື່ອມີການເຮັດທຸລະກຳ'),
(237, 'Server time', 'text', 'index', 0, 'เวลาเซิร์ฟเวอร์', NULL, 'ເວລາຂອງເຊີບເວີ'),
(238, 'Set the application for send an email', 'text', 'index', 0, 'เลือกโปรแกรมที่ใช้ในการส่งอีเมล', NULL, 'ເລືອກໂປຮແກຮມທີ່ໃຊ້ໃນການສົ່ງອີເມວ'),
(239, 'Setting up the email system', 'text', 'index', 0, 'การตั้งค่าเกี่ยวกับระบบอีเมล', NULL, 'ການຕັ້ງຄ່າກ່ຽວກັບລະບົບອີເມວ'),
(240, 'Settings', 'text', 'index', 0, 'ตั้งค่า', NULL, 'ຕັ້ງຄ່າ'),
(241, 'Settings the conditions for member login', 'text', 'index', 0, 'ตั้งค่าเงื่อนไขในการตรวจสอบการเข้าสู่ระบบ', NULL, 'ຕັ້ງເງື່ອນໄຂການກວດສອບການເຂົ້າລະບົບ'),
(242, 'Settings the timing of the server to match the local time', 'text', 'index', 0, 'ตั้งค่าเขตเวลาของเซิร์ฟเวอร์ ให้ตรงกันกับเวลาท้องถิ่น', NULL, 'ຕັ້ງຄ່າເຂດເວລາຂອງເຊີບເວີ ໃຫ້ກົງກັບເວລາທ້ອງຖີ່ນ'),
(243, 'Sex', 'text', 'index', 0, 'เพศ', NULL, 'ເພດ'),
(244, 'Short description about your website', 'text', 'index', 0, 'ข้อความสั้นๆอธิบายว่าเป็นเว็บไซต์เกี่ยวกับอะไร', NULL, 'ຂໍ້ຄວາມສັ້ນໆ ອະທິບາຍວ່າເປັນເວັບໄຊກ່ຽວກັບຫຍັງ'),
(245, 'Show', 'text', 'index', 0, 'แสดง', NULL, 'ສະແດງ'),
(246, 'Show web title with logo', 'text', 'index', 0, 'แสดงชื่อเว็บและโลโก', NULL, 'ສະແດງຊື່ເວັບແລະໂລໂກ້'),
(247, 'Site Name', 'text', 'index', 0, 'ชื่อของเว็บไซต์', NULL, 'ຊື່ຂອງເວັບໄຊ'),
(248, 'Site settings', 'text', 'index', 0, 'ตั้งค่าเว็บไซต์', NULL, 'ຕັ້ງຄ່າເວັບໄຊ'),
(249, 'size :width*:height pixel', 'text', 'index', 0, 'ขนาด :width*:height พิกเซล', NULL, 'ຂະໜາດ :width*:height ຟິດເຊວล'),
(250, 'Size of', 'text', 'index', 0, 'ขนาดของ', NULL, 'ຂະໜາດຂອງ'),
(251, 'skip to content', 'text', 'index', 0, 'ข้ามไปยังเนื้อหา', NULL, 'ຂ້າມໄປຍັງເນື້ອຫາ'),
(252, 'Sorry', 'text', 'index', 0, 'ขออภัย', NULL, 'ຂໍໂທດ'),
(253, 'Sorry, cannot find a page called Please check the URL or try the call again.', 'text', 'index', 0, 'ขออภัย ไม่พบหน้าที่เรียก โปรดตรวจสอบ URL หรือลองเรียกอีกครั้ง', NULL, 'ຂໍ​ອະ​ໄພ, ບໍ່​ສາ​ມາດ​ຊອກ​ຫາ​ຫນ້າ​ທີ່​ຮ້ອງ​ຂໍ. ກະ​ລຸ​ນາ​ກວດ​ສອບ URL ຫຼື​ພະ​ຍາ​ຍາມ​ດຶງ​ຂໍ້​ມູນ​ອີກ​ເທື່ອ​ຫນຶ່ງ.'),
(254, 'Sorry, Item not found It&#39;s may be deleted', 'text', 'index', 0, 'ขออภัย ไม่พบรายการที่เลือก รายการนี้อาจถูกลบไปแล้ว', NULL, 'ຂໍໂທດ ບໍ່ພົບລາຍການທີ່ເລືອກ ລາຍການນີ້ອາດຖືກລຶບໄປແລ້ວ'),
(255, 'Specify the language code of the email, as utf-8', 'text', 'index', 0, 'ระบุรหัสภาษาของอีเมลที่ส่ง เช่น utf-8', NULL, 'ລະບຸລະຫັດພາສາຂອງອີເມວທີ່ສົ່ງເຊັ່ນ utf-8'),
(256, 'Start a new line with the web name', 'text', 'index', 0, 'ขึ้นบรรทัดใหม่ชื่อเว็บ', NULL, 'ເລີ່ມແຖວໃໝ່ຊື່ເວັບ'),
(257, 'Status', 'text', 'index', 0, 'สถานะ', NULL, 'ສະຖານະ'),
(258, 'Status for general members', 'text', 'index', 0, 'สถานะสำหรับสมาชิกทั่วไป', NULL, 'ສະຖານະສຳລັບສະມາຊິກທົ່ວໄປ'),
(259, 'Style', 'text', 'index', 0, 'รูปแบบ', NULL, 'ຮູບແບບ'),
(260, 'Successfully deleted', 'text', 'index', 0, 'ลบเรียบร้อย', NULL, 'ລຶບສຳເລັດແລ້ວ'),
(261, 'Text color', 'text', 'index', 0, 'สีตัวอักษร', NULL, 'ສີຕົວອັກສອນ'),
(262, 'The e-mail address of the person or entity that has the authority to make decisions about the collection, use or dissemination of personal data.', 'text', 'index', 0, 'ที่อยู่อีเมลของบุคคลหรือนิติบุคคลที่มีอำนาจตัดสินใจเกี่ยวกับการเก็บรวบรวม ใช้ หรือเผยแพร่ข้อมูลส่วนบุคคล', NULL, 'ທີ່ຢູ່ອີເມລ໌ຂອງບຸກຄົນຫຼືຫນ່ວຍງານທີ່ມີອໍານາດໃນການຕັດສິນໃຈກ່ຽວກັບການລວບລວມ, ການນໍາໃຊ້ຫຼືການເຜີຍແຜ່ຂໍ້ມູນສ່ວນບຸກຄົນ.'),
(263, 'The members status of the site', 'text', 'index', 0, 'สถานะของสมาชิกของเว็บไซต์', NULL, 'ສະຖານະຂອງສະມາຂິກຂອງເວັບໄຊ'),
(264, 'The message has been sent to the admin successfully. Please wait a moment for the admin to approve the registration. You can log back in later if approved.', 'text', 'index', 0, 'ส่งข้อความไปยังผู้ดูแลระบบเรียบร้อยแล้ว กรุณารอสักครู่เพื่อให้ผู้ดูแลระบบอนุมัติการลงทะเบียน คุณสามารถกลับมาเข้าระบบได้ในภายหลังหากได้รับการอนุมัติแล้ว', NULL, 'ຂໍ້ຄວາມດັ່ງກ່າວໄດ້ຖືກສົ່ງໄປຫາຜູ້ເບິ່ງແຍງຢ່າງສໍາເລັດຜົນ. ກະລຸນາລໍຖ້າໃຫ້ຜູ້ເບິ່ງແຍງລະບົບອະນຸມັດການລົງທະບຽນ. ທ່ານສາມາດເຂົ້າສູ່ລະບົບຄືນໄດ້ໃນພາຍຫຼັງຖ້າໄດ້ຮັບການອະນຸມັດ.'),
(265, 'The name of the mail server as localhost or smtp.gmail.com (To change the settings of your email is the default. To remove this box entirely.)', 'text', 'index', 0, 'ชื่อของเมล์เซิร์ฟเวอร์ เช่น localhost หรือ smtp.gmail.com (ต้องการเปลี่ยนค่ากำหนดของอีเมลทั้งหมดเป็นค่าเริ่มต้น ให้ลบข้อความในช่องนี้ออกทั้งหมด)', NULL, 'ຊື່ຂອງເມວເຊີບເວີເຊັ່ນ localhost หรือ chitdpt@gmail.com (ຕ້ອງປ່ຽນຄ່າກຳນົດຂອງອີເມວທັງໝົດເປັນຄ່າເລີ່ມຕົ້ນ ໃຫ້ລຶບຂໍ້ຄວາມໃນຊ່ອງນີ້ອອກທັງໝົດ)'),
(266, 'The type of file is invalid', 'text', 'index', 0, 'ชนิดของไฟล์ไม่รองรับ', NULL, 'ຊະນິດຂອງແຟ້ມບໍ່ຮອງຮັບ'),
(267, 'Theme', 'text', 'index', 0, 'ธีม', NULL, 'ຮູບແບບສີສັນ'),
(268, 'This :name already exist', 'text', 'index', 0, 'มี :name นี้อยู่ก่อนแล้ว', NULL, 'ມີ :name ນີ້ຢູ່ກ່ອນແລ້ວ'),
(269, 'This website uses cookies to provide our services. To find out more about our use of cookies, please see our :privacy.', 'text', 'index', 0, 'เว็บไซต์นี้มีการใช้คุกกี้เพื่อปรับปรุงการให้บริการ หากต้องการข้อมูลเพิ่มเติมเกี่ยวกับการใช้คุกกี้ของเรา โปรดดู :privacy', NULL, 'ເວັບໄຊທ໌ນີ້ໃຊ້ຄຸກກີເພື່ອປັບປຸງການບໍລິການ. ສໍາລັບຂໍ້ມູນເພີ່ມເຕີມກ່ຽວກັບການນໍາໃຊ້ຄຸກກີຂອງພວກເຮົາ, ເບິ່ງ :privacy'),
(270, 'Time', 'text', 'index', 0, 'เวลา', NULL, 'ເວລາ'),
(271, 'Time zone', 'text', 'index', 0, 'เขตเวลา', NULL, 'ເຂດເວລາ'),
(272, 'times', 'text', 'index', 0, 'ครั้ง', NULL, 'ຄັ້ງ'),
(273, 'to', 'text', 'index', 0, 'ถึง', NULL, 'ເຖິງ'),
(274, 'To change your password, enter your password to match the two inputs', 'text', 'index', 0, 'ถ้าต้องการเปลี่ยนรหัสผ่าน กรุณากรอกรหัสผ่านสองช่องให้ตรงกัน', NULL, 'ຖ້າຕ້ອງການປ່ຽນລະຫັດຜ່ານກະລຸນາເພີ່ມລະຫັດຜ່ານສອງຊ່ອງໃຫ້ກົງກັນ'),
(275, 'Topic', 'text', 'index', 0, 'หัวข้อ', NULL, 'ຫົວຂໍ້'),
(276, 'Type', 'text', 'index', 0, 'ประเภท', NULL, 'ປະເພດ'),
(277, 'Unable to complete the transaction', 'text', 'index', 0, 'ไม่สามารถทำรายการนี้ได้', NULL, 'ບໍ່ສາມາດເຮັດລາຍການນີ້ໄດ້'),
(278, 'Upload', 'text', 'index', 0, 'อัปโหลด', NULL, 'ອັບໂຫຼດ'),
(279, 'Upload :type files', 'text', 'index', 0, 'อัปโหลดไฟล์ :type', NULL, 'ອັບໂຫຼດແຟ້ມຂໍ້ມູນ :type'),
(280, 'URL must begin with http:// or https://', 'text', 'index', 0, 'URL ต้องขึ้นต้นด้วย http:// หรือ https://', NULL, 'URL ຕ້ອງເລີ່ມຕົ້ນດ້ວຍ http:// ຫຼື https://'),
(281, 'Usage history', 'text', 'index', 0, 'ประวัติการใช้งาน', NULL, 'ປະ​ຫວັດ​ການ​ນໍາ​ໃຊ້​'),
(282, 'Use the theme&#039;s default settings.', 'text', 'index', 0, 'ใช้การตั้งค่าเริ่มต้นของธีม', NULL, 'ໃຊ້ການຕັ້ງຄ່າເລີ່ມຕົ້ນຂອງຮູບແບບສີສັນ.'),
(283, 'User', 'text', 'index', 0, 'สมาชิก', NULL, 'ສະມາຊິກ'),
(284, 'Username', 'text', 'index', 0, 'ชื่อผู้ใช้', NULL, 'ຊື່ຜູ້ໃຊ້'),
(285, 'Username for the mail server. (To change, enter a new value.)', 'text', 'index', 0, 'ชื่อผู้ใช้ของเมล์เซิร์ฟเวอร์ (ต้องการเปลี่ยน ให้กรอก)', NULL, 'ຊື່ຜູ້ໃຊ້ຂອງເມວເຊີບເວີ (ຕ້ອງການປ່ຽນ ໃຫ້ເພີ່ມ)'),
(286, 'Users', 'text', 'index', 0, 'สมาชิก', NULL, 'ສະມາຊິກ'),
(287, 'Version', 'text', 'index', 0, 'รุ่น', NULL, 'ຮຸ່ນ'),
(288, 'Waiting list', 'text', 'index', 0, 'รายการรอตรวจสอบ', NULL, 'ລາຍຊື່ລໍຖ້າ'),
(289, 'Waiting to check from the staff', 'text', 'index', 0, 'รอตรวจสอบจากเจ้าหน้าที่', NULL, 'ລໍຖ້າການກວດສອບຈາກພະນັກງານ'),
(290, 'Website template', 'text', 'index', 0, 'แม่แบบเว็บไซต์', NULL, 'ແມ່ແບບເວັບໄຊທ໌'),
(291, 'Website title', 'text', 'index', 0, 'ชื่อเว็บ', NULL, 'ຊື່ເວັບ'),
(292, 'Welcome', 'text', 'index', 0, 'สวัสดี', NULL, 'ສະບາຍດີ'),
(293, 'Welcome %s, login complete', 'text', 'index', 0, 'สวัสดี คุณ %s ยินดีต้อนรับเข้าสู่ระบบ', NULL, 'ສະບາຍດີທ່ານ %s ຍິນດີຕ້ອນຮັບເຂົ້າສູ່ລະບົບ'),
(294, 'Welcome new members', 'text', 'index', 0, 'ยินดีต้อนรับสมาชิกใหม่', NULL, 'ຍິນດີຕ້ອນຮັບສະມາຊິກໃໝ່'),
(295, 'When enabled Social accounts can be logged in as an administrator. (Some abilities will not be available)', 'text', 'index', 0, 'เมื่อเปิดใช้งาน บัญชีโซเชียลจะสามารถเข้าระบบเป็นผู้ดูแลได้ (ความสามารถบางอย่างจะไม่สามารถใช้งานได้)', NULL, 'ເມື່ອເປີດໃຊ້ງານ ບັນຊີສັງຄົມສາມາດເຂົ້າສູ່ລະບົບເປັນຜູ້ບໍລິຫານ. (ຄວາມສາມາດບາງຢ່າງຈະບໍ່ມີ)'),
(296, 'When enabled, a cookies consent banner will be displayed.', 'text', 'index', 0, 'เมื่อเปิดใช้งานระบบจะแสดงแบนเนอร์ขออนุญาตใช้งานคุ้กกี้', NULL, 'ເມື່ອເປີດໃຊ້ງານແລ້ວ, ປ້າຍໂຄສະນາການຍິນຍອມຂອງ cookies ຈະສະແດງຂຶ້ນ.'),
(297, 'When enabled, Members registered with email must also verify their email address. It is not recommended to use in conjunction with other login methods.', 'text', 'index', 0, 'เมื่อเปิดใช้งาน สมาชิกที่ลงทะเบียนด้วยอีเมลจะต้องยืนยันที่อยู่อีเมลด้วย ไม่แนะนำให้ใช้ร่วมกับการเข้าระบบด้วยช่องทางอื่นๆ', NULL, 'ເມື່ອເປີດໃຊ້ ສະມາຊິກທີ່ລົງທະບຽນກັບອີເມລ໌ຈະຕ້ອງຢືນຢັນທີ່ຢູ່ອີເມວຂອງເຂົາເຈົ້າ. ມັນບໍ່ໄດ້ຖືກແນະນໍາໃຫ້ໃຊ້ຮ່ວມກັບວິທີການເຂົ້າສູ່ລະບົບອື່ນໆ.'),
(298, 'Width', 'text', 'index', 0, 'กว้าง', NULL, 'ກວ້າງ'),
(299, 'With selected', 'text', 'index', 0, 'ทำกับที่เลือก', NULL, 'ເຮັດກັບທີ່ເລືອກ'),
(300, 'year', 'text', 'index', 0, 'ปี', NULL, 'ປີ'),
(301, 'You can enter your LINE user ID below on your personal information page. to link your account to this official account', 'text', 'index', 0, 'คุณสามารถกรอก LINE user ID ด้านล่างในหน้าข้อมูลส่วนตัวของคุณ เพื่อผูกบัญชีของคุณเข้ากับบัญชีทางการนี้ได้', NULL, 'ທ່ານສາມາດໃສ່ LINE user ID ຂອງທ່ານຂ້າງລຸ່ມນີ້ຢູ່ໃນຫນ້າຂໍ້ມູນສ່ວນຕົວຂອງທ່ານ. ເພື່ອເຊື່ອມຕໍ່ບັນຊີຂອງທ່ານກັບບັນຊີທາງການນີ້'),
(302, 'You can login at', 'text', 'index', 0, 'คุณสามารถเข้าระบบได้ที่', NULL, 'ທ່ານສາມາດເຂົ້າສູ່ລະບົບໄດ້ທີ່'),
(303, 'You haven&#039;t verified your email address. Please check your email. and click the link in the email', 'text', 'index', 0, 'คุณยังไม่ได้ยืนยันที่อยู่อีเมล กรุณาตรวจสอบอีเมลของคุณ และคลิกลิงค์ในอีเมล', NULL, 'ທ່ານຍັງບໍ່ໄດ້ຢືນຢັນທີ່ຢູ່ອີເມວຂອງທ່ານ. ກະລຸນາກວດເບິ່ງອີເມວຂອງທ່ານ. ແລະຄລິກໃສ່ການເຊື່ອມຕໍ່ໃນອີເມລ໌'),
(304, 'You want to', 'text', 'index', 0, 'คุณต้องการ', NULL, 'ທ່ານຕ້ອງການ'),
(305, 'Your account has been approved.', 'text', 'index', 0, 'บัญชีของท่านได้รับการอนุมัติเรียบร้อยแล้ว', NULL, 'ບັນຊີຂອງທ່ານໄດ້ຮັບການອະນຸມັດແລ້ວ.'),
(306, 'Your account has not been approved, please wait or contact the administrator.', 'text', 'index', 0, 'บัญชีของท่านยังไม่ได้รับการอนุมัติ กรุณารอ หรือติดต่อสอบถามไปยังผู้ดูแล', NULL, 'ບັນຊີຂອງທ່ານບໍ່ໄດ້ຮັບການອະນຸມັດ, ກະລຸນາລໍຖ້າ ຫຼືຕິດຕໍ່ຜູ້ເບິ່ງແຍງລະບົບ.'),
(307, 'Your message was sent successfully', 'text', 'index', 0, 'ส่งข้อความไปยังผู้ที่เกี่ยวข้องเรียบร้อยแล้ว', NULL, 'ສົ່ງຂໍ້ຄວາມໄປຍັງຜູ້ຮັບຮຽບຮ້ອຍແລ້ວ'),
(308, 'Your new password is', 'text', 'index', 0, 'รหัสผ่านใหม่ของคุณคือ', NULL, 'ລະຫັດຜ່ານໃໝ່ຂອງທ່ານຄື'),
(309, 'Your registration information', 'text', 'index', 0, 'ข้อมูลการลงทะเบียนของคุณ', NULL, 'ຂໍ້ມູນການລົງທະບຽນຂອງທ່ານ'),
(310, 'Zipcode', 'text', 'index', 0, 'รหัสไปรษณีย์', NULL, 'ລະຫັດໄປສະນີ');

-- --------------------------------------------------------

--
-- Table structure for table `booking_logs`
--

CREATE TABLE `booking_logs` (
  `id` int(11) NOT NULL,
  `src_id` int(11) NOT NULL,
  `module` varchar(20) NOT NULL,
  `action` varchar(20) NOT NULL,
  `create_date` datetime NOT NULL,
  `reason` text DEFAULT NULL,
  `member_id` int(11) DEFAULT NULL,
  `topic` text NOT NULL,
  `datas` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `booking_logs`
--

INSERT INTO `booking_logs` (`id`, `src_id`, `module`, `action`, `create_date`, `reason`, `member_id`, `topic`, `datas`) VALUES
(1, 1, 'index', 'User', '2023-07-19 13:30:16', NULL, 1, '{LNG_Login} IP ::1', NULL),
(2, 0, 'index', 'Save', '2023-07-19 13:30:29', NULL, 1, '{LNG_General site settings}', NULL),
(3, 0, 'index', 'Save', '2023-07-19 13:30:38', NULL, 1, '{LNG_General site settings}', NULL),
(4, 0, 'index', 'Save', '2023-07-19 13:30:50', NULL, 1, '{LNG_General site settings}', NULL),
(5, 0, 'index', 'Save', '2023-07-19 13:32:50', NULL, 1, '{LNG_General site settings}', NULL),
(6, 3, 'index', 'User', '2023-07-19 13:33:21', NULL, 3, '{LNG_Create new account} ID : 3', NULL),
(7, 1, 'index', 'User', '2023-07-19 13:34:02', NULL, 1, '{LNG_Login} IP ::1', NULL),
(8, 0, 'index', 'Save', '2023-07-19 13:34:19', NULL, 1, '{LNG_General site settings}', NULL),
(9, 4, 'index', 'User', '2023-07-19 13:59:39', NULL, 4, '{LNG_Create new account} ID : 4', NULL),
(10, 1, 'index', 'User', '2023-07-19 14:00:29', NULL, 1, '{LNG_Login} IP ::1', NULL),
(11, 0, 'index', 'Save', '2023-07-19 14:01:05', NULL, 1, '{LNG_General site settings}', NULL),
(12, 5, 'index', 'User', '2023-07-19 14:01:37', NULL, 5, '{LNG_Create new account} ID : 5', NULL),
(13, 1, 'index', 'User', '2023-07-19 14:01:51', NULL, 1, '{LNG_Login} IP ::1', NULL),
(14, 0, 'index', 'Save', '2023-07-19 14:02:05', NULL, 1, '{LNG_General site settings}', NULL),
(15, 1, 'index', 'User', '2023-07-19 14:02:51', NULL, 1, '{LNG_Login} IP ::1', NULL),
(16, 0, 'index', 'Save', '2023-07-19 14:03:05', NULL, 1, '{LNG_General site settings}', NULL),
(17, 6, 'index', 'User', '2023-07-19 14:03:27', NULL, 6, '{LNG_Create new account} ID : 6', NULL),
(18, 6, 'index', 'User', '2023-07-19 14:03:37', NULL, 6, '{LNG_Login} IP ::1', NULL),
(19, 1, 'index', 'User', '2023-07-19 14:26:37', NULL, 1, '{LNG_Login} IP ::1', NULL),
(20, 8, 'booking', 'Save', '2023-07-19 14:46:52', NULL, 1, '{LNG_Room} ID : 8', NULL),
(21, 8, 'booking', 'Save', '2023-07-19 14:47:20', NULL, 1, '{LNG_Room} ID : 8', NULL),
(22, 7, 'booking', 'Save', '2023-07-19 14:47:57', NULL, 1, '{LNG_Room} ID : 7', NULL),
(23, 6, 'booking', 'Save', '2023-07-19 14:48:51', NULL, 1, '{LNG_Room} ID : 6', NULL),
(24, 5, 'booking', 'Save', '2023-07-19 14:49:47', NULL, 1, '{LNG_Room} ID : 5', NULL),
(25, 8, 'booking', 'Save', '2023-07-19 14:50:07', NULL, 1, '{LNG_Room} ID : 8', NULL),
(26, 4, 'booking', 'Save', '2023-07-19 14:50:45', NULL, 1, '{LNG_Room} ID : 4', NULL),
(27, 4, 'booking', 'Save', '2023-07-19 14:51:00', NULL, 1, '{LNG_Room} ID : 4', NULL),
(28, 3, 'booking', 'Save', '2023-07-19 14:51:19', NULL, 1, '{LNG_Room} ID : 3', NULL),
(29, 5, 'booking', 'Save', '2023-07-19 14:51:42', NULL, 1, '{LNG_Room} ID : 5', NULL),
(30, 3, 'booking', 'Save', '2023-07-19 14:59:44', NULL, 1, '{LNG_Room} ID : 3', NULL),
(31, 3, 'booking', 'Save', '2023-07-19 15:00:21', NULL, 1, '{LNG_Room} ID : 3', NULL),
(32, 4, 'booking', 'Save', '2023-07-19 15:00:40', NULL, 1, '{LNG_Room} ID : 4', NULL),
(33, 2, 'booking', 'Save', '2023-07-19 15:01:40', NULL, 1, '{LNG_Room} ID : 2', NULL),
(34, 1, 'booking', 'Save', '2023-07-19 15:02:13', NULL, 1, '{LNG_Room} ID : 1', NULL),
(35, 0, 'index', 'Save', '2023-07-19 15:08:33', NULL, 1, '{LNG_General site settings}', NULL),
(36, 0, 'index', 'Save', '2023-07-19 15:08:53', NULL, 1, '{LNG_General site settings}', NULL),
(37, 0, 'index', 'Save', '2023-07-19 15:10:14', NULL, 1, '{LNG_General site settings}', NULL),
(38, 1, 'index', 'User', '2023-07-19 15:26:49', NULL, 1, '{LNG_Login} IP ::1', NULL),
(39, 1, 'booking', 'Status', '2023-07-19 16:16:51', NULL, 1, 'รอตรวจสอบ', NULL),
(40, 1, 'booking', 'Status', '2023-07-19 16:17:30', NULL, 1, 'อนุมัติ', NULL),
(41, 7, 'index', 'User', '2023-07-19 16:18:19', NULL, 7, '{LNG_Create new account} ID : 7', NULL),
(42, 7, 'index', 'User', '2023-07-19 16:18:30', NULL, 7, '{LNG_Login} IP ::1', NULL),
(43, 2, 'booking', 'Status', '2023-07-19 16:19:20', NULL, 7, 'รอตรวจสอบ', NULL),
(44, 1, 'index', 'User', '2023-07-19 16:19:36', NULL, 1, '{LNG_Login} IP ::1', NULL),
(45, 2, 'booking', 'Status', '2023-07-19 16:19:44', NULL, 1, 'อนุมัติ', NULL),
(46, 7, 'index', 'User', '2023-07-19 16:19:55', NULL, 7, '{LNG_Login} IP ::1', NULL),
(47, 7, 'index', 'User', '2023-07-20 08:37:13', NULL, 7, '{LNG_Login} IP ::1', NULL),
(48, 7, 'index', 'User', '2023-07-20 10:43:03', NULL, 7, '{LNG_Login} IP ::1', NULL),
(49, 7, 'index', 'User', '2023-07-20 11:00:26', NULL, 7, '{LNG_Editing your account} ID : 7', NULL),
(50, 8, 'index', 'User', '2023-07-20 11:07:35', NULL, 8, '{LNG_Create new account} ID : 8', NULL),
(51, 8, 'index', 'User', '2023-07-20 11:07:51', NULL, 8, '{LNG_Login} IP ::1', NULL),
(52, 8, 'index', 'User', '2023-07-20 11:08:18', NULL, 8, '{LNG_Editing your account} ID : 8', NULL),
(53, 3, 'booking', 'Status', '2023-07-20 11:09:02', NULL, 8, 'รอตรวจสอบ', NULL),
(54, 1, 'index', 'User', '2023-07-20 11:09:39', NULL, 1, '{LNG_Login} IP ::1', NULL),
(55, 1, 'index', 'User', '2023-07-20 11:10:05', NULL, 1, '{LNG_Editing your account} ID : 8', NULL),
(56, 0, 'index', 'User', '2023-07-20 11:11:06', NULL, 1, '{LNG_Delete} {LNG_User} ID : 8, 7, 6, 5, 3, 2', NULL),
(57, 1, 'index', 'User', '2023-07-20 11:11:48', NULL, 1, '{LNG_Editing your account} ID : 1', NULL),
(58, 4, 'booking', 'Status', '2023-07-20 11:12:23', NULL, 1, 'รอตรวจสอบ', NULL),
(59, 3, 'booking', 'Status', '2023-07-20 11:12:59', NULL, 1, 'ยกเลิกโดยเจ้าหน้าที่', NULL),
(60, 4, 'booking', 'Status', '2023-07-20 11:13:06', NULL, 1, 'อนุมัติ', NULL),
(61, 9, 'index', 'User', '2023-07-20 11:14:20', NULL, 9, '{LNG_Create new account} ID : 9', NULL),
(62, 9, 'index', 'User', '2023-07-20 11:14:32', NULL, 9, '{LNG_Login} IP ::1', NULL),
(63, 9, 'index', 'User', '2023-07-20 11:24:15', NULL, 9, '{LNG_Editing your account} ID : 9', NULL),
(64, 1, 'booking', 'Status', '2023-07-20 11:28:26', NULL, 9, 'รอตรวจสอบ', NULL),
(65, 1, 'index', 'User', '2023-07-20 11:28:48', NULL, 1, '{LNG_Login} IP ::1', NULL),
(66, 1, 'booking', 'Status', '2023-07-20 11:29:02', NULL, 1, 'อนุมัติ', NULL),
(67, 2, 'booking', 'Status', '2023-07-20 12:03:36', NULL, 1, 'รอตรวจสอบ', NULL),
(68, 2, 'booking', 'Status', '2023-07-20 12:03:44', NULL, 1, 'รอตรวจสอบ', NULL),
(69, 2, 'booking', 'Status', '2023-07-20 12:03:52', NULL, 1, 'อนุมัติ', NULL),
(70, 1, 'index', 'User', '2023-07-20 13:01:06', NULL, 1, '{LNG_Login} IP ::1', NULL),
(71, 3, 'booking', 'Status', '2023-07-20 13:01:50', NULL, 1, 'รอตรวจสอบ', NULL),
(72, 3, 'booking', 'Status', '2023-07-20 13:02:31', NULL, 1, 'อนุมัติ', NULL),
(73, 0, 'booking', 'Delete', '2023-07-20 13:04:06', NULL, 1, '{LNG_Delete} {LNG_Book a room} ID : 1, 2, 3', NULL),
(74, 1, 'booking', 'Status', '2023-07-20 13:04:43', NULL, 1, 'รอตรวจสอบ', NULL),
(75, 1, 'booking', 'Status', '2023-07-20 13:04:56', NULL, 1, 'อนุมัติ', NULL),
(76, 0, 'booking', 'Delete', '2023-07-20 13:05:47', NULL, 1, '{LNG_Delete} {LNG_Book a room} ID : 1', NULL),
(77, 1, 'booking', 'Status', '2023-07-20 13:12:40', NULL, 1, 'รอตรวจสอบ', NULL),
(78, 1, 'booking', 'Status', '2023-07-20 13:12:56', NULL, 1, 'อนุมัติ', NULL),
(79, 0, 'booking', 'Delete', '2023-07-20 13:14:08', NULL, 1, '{LNG_Delete} {LNG_Book a room} ID : 1', NULL),
(80, 1, 'booking', 'Status', '2023-07-20 13:14:31', NULL, 1, 'รอตรวจสอบ', NULL),
(81, 1, 'booking', 'Status', '2023-07-20 13:14:44', NULL, 1, 'อนุมัติ', NULL),
(82, 2, 'booking', 'Status', '2023-07-20 13:16:04', NULL, 1, 'รอตรวจสอบ', NULL),
(83, 2, 'booking', 'Status', '2023-07-20 13:16:16', NULL, 1, 'อนุมัติ', NULL),
(84, 0, 'booking', 'Delete', '2023-07-20 13:20:55', NULL, 1, '{LNG_Delete} {LNG_Book a room} ID : 1, 2', NULL),
(85, 1, 'booking', 'Status', '2023-07-20 13:24:47', NULL, 1, 'รอตรวจสอบ', NULL),
(86, 1, 'booking', 'Status', '2023-07-20 13:25:15', NULL, 1, 'อนุมัติ', NULL),
(87, 2, 'booking', 'Status', '2023-07-20 13:27:38', NULL, 1, 'รอตรวจสอบ', NULL),
(88, 2, 'booking', 'Status', '2023-07-20 13:27:48', NULL, 1, 'อนุมัติ', NULL),
(89, 3, 'booking', 'Status', '2023-07-20 13:28:47', NULL, 1, 'รอตรวจสอบ', NULL),
(90, 3, 'booking', 'Status', '2023-07-20 13:29:08', NULL, 1, 'อนุมัติ', NULL),
(91, 0, 'booking', 'Delete', '2023-07-20 13:29:53', NULL, 1, '{LNG_Delete} {LNG_Book a room} ID : 1, 2, 3', NULL),
(92, 1, 'booking', 'Status', '2023-07-20 13:30:20', NULL, 1, 'รอตรวจสอบ', NULL),
(93, 1, 'booking', 'Status', '2023-07-20 13:30:33', NULL, 1, 'อนุมัติ', NULL),
(94, 2, 'booking', 'Status', '2023-07-20 13:31:36', NULL, 1, 'รอตรวจสอบ', NULL),
(95, 2, 'booking', 'Status', '2023-07-20 13:31:46', NULL, 1, 'อนุมัติ', NULL),
(96, 2, 'booking', 'Status', '2023-07-20 13:40:17', NULL, 1, 'อนุมัติ', NULL),
(97, 1, 'booking', 'Status', '2023-07-20 13:50:24', NULL, 1, 'อนุมัติ', NULL),
(98, 1, 'index', 'User', '2023-07-20 14:50:38', NULL, 1, '{LNG_Login} IP ::1', NULL),
(99, 1, 'booking', 'Status', '2023-07-20 14:56:21', NULL, 1, 'อนุมัติ', NULL),
(100, 1, 'index', 'User', '2023-07-20 15:30:57', NULL, 1, '{LNG_Login} IP ::1', NULL),
(101, 1, 'index', 'User', '2023-07-21 08:00:16', NULL, 1, '{LNG_Login} IP ::1', NULL),
(102, 1, 'index', 'User', '2023-07-21 09:00:23', NULL, 1, '{LNG_Login} IP ::1', NULL),
(103, 3, 'booking', 'Status', '2023-07-21 09:46:20', NULL, 1, 'รอตรวจสอบ', NULL),
(104, 1, 'index', 'User', '2023-07-21 10:05:09', NULL, 1, '{LNG_Login} IP ::1', NULL),
(105, 3, 'booking', 'Status', '2023-07-21 10:25:04', NULL, 1, 'รอตรวจสอบ', NULL),
(106, 4, 'booking', 'Status', '2023-07-21 10:37:02', NULL, 1, 'รอตรวจสอบ', NULL),
(107, 4, 'booking', 'Status', '2023-07-21 10:37:17', NULL, 1, 'รอตรวจสอบ', NULL),
(108, 4, 'booking', 'Status', '2023-07-21 10:37:37', NULL, 1, 'อนุมัติ', NULL),
(109, 0, 'booking', 'Delete', '2023-07-21 10:38:11', NULL, 1, '{LNG_Delete} {LNG_Book a room} ID : 1, 2, 3, 4', NULL),
(110, 10, 'index', 'User', '2023-07-21 10:41:15', NULL, 10, '{LNG_Create new account} ID : 10', NULL),
(111, 10, 'index', 'User', '2023-07-21 10:41:22', NULL, 10, '{LNG_Login} IP ::1', NULL),
(112, 10, 'index', 'User', '2023-07-21 10:41:52', NULL, 10, '{LNG_Editing your account} ID : 10', NULL),
(113, 1, 'booking', 'Status', '2023-07-21 10:42:34', NULL, 10, 'รอตรวจสอบ', NULL),
(114, 1, 'index', 'User', '2023-07-21 10:43:23', NULL, 1, '{LNG_Login} IP ::1', NULL),
(115, 11, 'index', 'User', '2023-07-21 10:44:19', NULL, 11, '{LNG_Create new account} ID : 11', NULL),
(116, 1, 'index', 'User', '2023-07-21 10:44:33', NULL, 1, '{LNG_Login} IP ::1', NULL),
(117, 1, 'index', 'User', '2023-07-21 10:44:55', NULL, 1, '{LNG_Editing your account} ID : 11', NULL),
(118, 12, 'index', 'User', '2023-07-21 10:47:41', NULL, 12, '{LNG_Create new account} ID : 12', NULL),
(119, 12, 'index', 'User', '2023-07-21 10:47:49', NULL, 12, '{LNG_Login} IP ::1', NULL),
(120, 2, 'booking', 'Status', '2023-07-21 10:49:06', NULL, 12, 'รอตรวจสอบ', NULL),
(121, 1, 'index', 'User', '2023-07-21 10:49:36', NULL, 1, '{LNG_Login} IP ::1', NULL),
(122, 2, 'booking', 'Status', '2023-07-21 10:51:47', NULL, 1, 'อนุมัติ', NULL),
(123, 2, 'booking', 'Status', '2023-07-21 10:52:07', NULL, 1, 'ไม่อนุมัติ', NULL),
(124, 2, 'booking', 'Status', '2023-07-21 10:52:18', NULL, 1, 'อนุมัติ', NULL),
(125, 2, 'booking', 'Status', '2023-07-21 10:52:54', NULL, 1, 'ไม่อนุมัติ', NULL),
(126, 3, 'booking', 'Status', '2023-07-21 11:12:26', NULL, 1, 'รอตรวจสอบ', NULL),
(127, 12, 'index', 'User', '2023-07-21 11:13:08', NULL, 12, '{LNG_Login} IP ::1', NULL),
(128, 4, 'booking', 'Status', '2023-07-21 11:13:24', NULL, 12, 'รอตรวจสอบ', NULL),
(129, 0, 'booking', 'Status', '2023-07-21 11:13:36', NULL, 12, 'ยกเลิกโดยผู้จอง ID : 4', NULL),
(130, 1, 'index', 'User', '2023-07-21 11:13:51', NULL, 1, '{LNG_Login} IP ::1', NULL),
(131, 13, 'index', 'User', '2023-07-21 11:53:11', NULL, 13, '{LNG_Create new account} ID : 13', NULL),
(132, 13, 'index', 'User', '2023-07-21 11:54:12', NULL, 13, '{LNG_Login} IP ::1', NULL),
(133, 5, 'booking', 'Status', '2023-07-21 11:54:43', NULL, 13, 'รอตรวจสอบ', NULL),
(134, 1, 'index', 'User', '2023-07-21 15:04:50', NULL, 1, '{LNG_Login} IP ::1', NULL),
(135, 0, 'index', 'User', '2023-07-21 15:07:00', NULL, 1, '{LNG_Send member confirmation email} ID : 13', NULL),
(136, 1, 'index', 'User', '2023-07-21 15:07:58', NULL, 1, '{LNG_Login} IP ::1', NULL),
(137, 0, 'index', 'User', '2023-07-21 15:08:43', NULL, 1, '{LNG_Email address verification} ID : 13', NULL),
(138, 0, 'booking', 'Delete', '2023-07-21 15:10:15', NULL, 1, '{LNG_Delete} {LNG_Book a room} ID : 1, 2, 3, 4, 5', NULL),
(139, 1, 'booking', 'Status', '2023-07-21 15:10:39', NULL, 1, 'รอตรวจสอบ', NULL),
(140, 0, 'booking', 'Delete', '2023-07-21 15:10:48', NULL, 1, '{LNG_Delete} {LNG_Book a room} ID : 1', NULL),
(141, 12, 'index', 'User', '2023-07-21 15:12:00', NULL, 12, '{LNG_Login} IP ::1', NULL),
(142, 1, 'index', 'User', '2023-07-21 15:18:29', NULL, 1, '{LNG_Login} IP ::1', NULL),
(143, 1, 'booking', 'Status', '2023-07-21 15:18:50', NULL, 1, 'รอตรวจสอบ', NULL),
(144, 0, 'booking', 'Delete', '2023-07-21 15:19:12', NULL, 1, '{LNG_Delete} {LNG_Book a room} ID : 1', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `booking_reservation`
--

CREATE TABLE `booking_reservation` (
  `id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `create_date` datetime DEFAULT NULL,
  `topic` varchar(150) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `attendees` int(11) NOT NULL,
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `reason` varchar(128) DEFAULT NULL,
  `approver` int(11) NOT NULL,
  `approved_date` datetime DEFAULT NULL,
  `id_card` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `booking_reservation_data`
--

CREATE TABLE `booking_reservation_data` (
  `reservation_id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `value` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `booking_rooms`
--

CREATE TABLE `booking_rooms` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `detail` text NOT NULL,
  `color` varchar(20) NOT NULL,
  `published` int(1) NOT NULL DEFAULT 1
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `booking_rooms`
--

INSERT INTO `booking_rooms` (`id`, `name`, `detail`, `color`, `published`) VALUES
(1, 'ห้องปฎิบัติการคอมพิวเตอร์', 'ห้องปฎิบัติการคอมพิวเตอร์ 40 คน', '#01579B', 1),
(2, 'ห้องเรียน', 'ห้องเรียน 80 คน', '#01579B', 1),
(3, 'ห้องปฏิบัติการคอมพิวเตอร์', 'ห้องปฏิบัติการคอมพิวเตอร์', '#01579B', 1),
(4, 'ห้องปฏิบัติการ Circuit', 'ห้องปฏิบัติการ Circuit', '#01579B', 1),
(5, 'ห้องเรียน', 'ห้องเรียน 40 คน', '#01579B', 1),
(6, 'ห้องเรียน', 'ห้องเรียน 80 คน', '#01579B', 1),
(7, 'ห้องเรียน', 'ห้องเรียน 40 คน', '#01579B', 1),
(8, 'ห้องปฎิบัติการ Circuit', 'ห้องปฎิบัติการ Circuit', '#01579B', 1);

-- --------------------------------------------------------

--
-- Table structure for table `booking_rooms_meta`
--

CREATE TABLE `booking_rooms_meta` (
  `room_id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `value` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `booking_rooms_meta`
--

INSERT INTO `booking_rooms_meta` (`room_id`, `name`, `value`) VALUES
(2, 'number', '1113'),
(2, 'building', 'วิศววัฒนะ'),
(1, 'number', '1112'),
(1, 'building', 'วิศววัฒนะ'),
(3, 'number', '1114'),
(8, 'number', '1121'),
(8, 'seats', '80 ที่นั่ง'),
(8, 'building', 'วิศววัฒนะ'),
(7, 'building', 'วิศววัฒนะ'),
(7, 'number', '1119'),
(6, 'building', 'วิศววัฒนะ'),
(6, 'number', '1118'),
(5, 'building', 'วิศววัฒนะ'),
(4, 'number', '1115'),
(4, 'seats', '80 ที่นั่ง'),
(4, 'building', 'วิศววัฒนะ'),
(3, 'seats', '40 ที่นั่ง'),
(5, 'number', '1116'),
(5, 'seats', '40 ที่นั่ง'),
(3, 'building', 'วิศววัฒนะ'),
(1, 'seats', '40 ที่นั่ง');

-- --------------------------------------------------------

--
-- Table structure for table `booking_user`
--

CREATE TABLE `booking_user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `salt` varchar(32) NOT NULL,
  `password` varchar(50) NOT NULL,
  `token` varchar(50) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 0,
  `permission` text NOT NULL,
  `name` varchar(150) NOT NULL,
  `id_card` varchar(59) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `sex` varchar(50) NOT NULL,
  `address` varchar(150) DEFAULT NULL,
  `phone` varchar(32) DEFAULT NULL,
  `provinceID` varchar(3) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `zipcode` varchar(10) DEFAULT NULL,
  `country` varchar(2) DEFAULT 'TH',
  `create_date` datetime DEFAULT NULL,
  `active` tinyint(1) DEFAULT 1,
  `social` tinyint(1) DEFAULT 0,
  `line_uid` varchar(33) DEFAULT NULL,
  `activatecode` varchar(32) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `booking_user`
--

INSERT INTO `booking_user` (`id`, `username`, `salt`, `password`, `token`, `status`, `permission`, `name`, `id_card`, `sex`, `address`, `phone`, `provinceID`, `province`, `zipcode`, `country`, `create_date`, `active`, `social`, `line_uid`, `activatecode`) VALUES
(1, 'admin@cpe', '64b782c5c9669', '8b2ba5623c3516cef08b70b17ada0c5706da92ae', '65ac38d79517eb6ad69d86ba849319947dcdf5d4', 1, '', 'แอดมิน', '64202040015', '', '', '0967207771', '', '', '', '', '2023-07-19 08:29:25', 1, 0, NULL, ''),
(9, 'tangsiwon', 'ae7be11436e73', '37d3603fef74d5aea6414b859a167f903b22057c', 'b30a41bdad941ee1df4c84b36e8684157cc11f76', 0, '', 'นาย ธนพัฒน์ บุญรักษ์', '64202040018', '', '', '0967207771', '', '', '', '', '2023-07-20 11:14:20', 1, 0, NULL, ''),
(10, 'Wave', '15c4336a2cf15', '98355088afc49aaae9899b3bb037f5041dbdc36d', 'a44257f9d5afff733ba276685a924395d86fe575', 0, '', 'นาย พนม พยัคษา', '64202040024', '', '', '0976720771', '', '', '', '', '2023-07-21 10:41:15', 1, 0, NULL, ''),
(11, 'staff', '41cf130407a56', '905058bf1884e2775d5e15582345fc575116fa1e', NULL, 2, '', 'ผู้ดูแล', '', '', '', NULL, '', '', '', '', '2023-07-21 10:44:19', 1, 0, NULL, ''),
(12, 'Wave1', '307548050291c', 'ef69277a63e272ef20c1626c02bc64df5949efd0', '96b1a9be402c315ac67dc54c8384f6d9882ca51b', 0, '', 'นาย พนม พยัคษา', '', '', NULL, '0967207771', NULL, NULL, NULL, 'TH', '2023-07-21 10:47:40', 1, 0, NULL, ''),
(13, 'OAT', '693070a1bae65', 'd97d1d55768feddce1452a7057f633aeb84b406d', 'fab2b29222cc3d2079e7ea01c0ab16a4fe6d0e21', 0, '', 'นาย สุรพจ ทองเพชร', '', '', NULL, '0123456789', NULL, NULL, NULL, 'TH', '2023-07-21 11:53:11', 1, 0, NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `booking_user_meta`
--

CREATE TABLE `booking_user_meta` (
  `value` varchar(10) NOT NULL,
  `name` varchar(10) DEFAULT NULL,
  `member_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking_category`
--
ALTER TABLE `booking_category`
  ADD PRIMARY KEY (`Field`),
  ADD KEY `type` (`type`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `booking_language`
--
ALTER TABLE `booking_language`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booking_logs`
--
ALTER TABLE `booking_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `src_id` (`src_id`),
  ADD KEY `module` (`module`),
  ADD KEY `action` (`action`);

--
-- Indexes for table `booking_reservation`
--
ALTER TABLE `booking_reservation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booking_reservation_data`
--
ALTER TABLE `booking_reservation_data`
  ADD KEY `reservation_id` (`reservation_id`);

--
-- Indexes for table `booking_rooms`
--
ALTER TABLE `booking_rooms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booking_rooms_meta`
--
ALTER TABLE `booking_rooms_meta`
  ADD KEY `room_id` (`room_id`);

--
-- Indexes for table `booking_user`
--
ALTER TABLE `booking_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `line_uid` (`line_uid`),
  ADD KEY `username` (`username`),
  ADD KEY `token` (`token`),
  ADD KEY `phone` (`phone`),
  ADD KEY `activatecode` (`activatecode`);

--
-- Indexes for table `booking_user_meta`
--
ALTER TABLE `booking_user_meta`
  ADD KEY `member_id` (`member_id`,`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking_category`
--
ALTER TABLE `booking_category`
  MODIFY `Field` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `booking_language`
--
ALTER TABLE `booking_language`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=311;

--
-- AUTO_INCREMENT for table `booking_logs`
--
ALTER TABLE `booking_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=145;

--
-- AUTO_INCREMENT for table `booking_reservation`
--
ALTER TABLE `booking_reservation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `booking_user`
--
ALTER TABLE `booking_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
