<?php
/**
 * @filesource modules/index/controllers/api.php
 *
 * @copyright 2016 Goragod.com
 * @license https://www.kotchasan.com/license/
 *
 * @see https://www.kotchasan.com/
 */

namespace Index\Api;

/**
 * Controller สำหรับโหลดข้อมูลด้วย Api
 *
 * @author Goragod Wiriya <admin@goragod.com>
 *
 * @since 1.0
 */
class Controller extends \Kotchasan\ApiController
{

}
