<?php
/* Theme default settings */
return array(
    'name' => 'Default',
    'header_bg_color' => '#3498DB',
    'warpper_bg_color' => '#F9F9F9',
    'header_color' => '#FFFFFF',
    'footer_color' => '#7E7E7E',
    'logo_color' => '#FFFFFF',
    'login_message_style' => 'hidden',
    'login_header_color' => '#FFFFFF',
    'login_footer_color' => '#FFFFFF',
    'login_color' => '#FFFFFF',
    'login_bg_color' => '#3498DB',
    'theme_width' => 'default'
);
