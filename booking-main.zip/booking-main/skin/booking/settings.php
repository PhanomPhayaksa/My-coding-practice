<?php
/* Theme default settings */
return array(
    'name' => 'Booking',
    'header_bg_color' => '#3498DB',
    'warpper_bg_color' => '#D2D2D2',
    'header_color' => '#FFFFFF',
    'footer_color' => '#7E7E7E',
    'logo_color' => '#000000',
    'login_header_color' => '#000000',
    'login_footer_color' => '#7E7E7E',
    'login_color' => '#000000',
    'login_bg_color' => '#D2D2D2',
    'theme_width' => 'wide'
);
