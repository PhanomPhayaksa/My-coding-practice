<?php exit();?>
[2023-07-19 13:33:21] ERROR: <br>PHP warning : <em>Undefined variable $user_categories</em> in <b>C:\xampp\htdocs\booking-main!\modules\index\models\register.php</b> on line <b>135</b> 
[2023-07-19 13:33:21] ERROR: <br>PHP warning : <em>foreach() argument must be of type array|object, null given</em> in <b>C:\xampp\htdocs\booking-main!\modules\index\models\register.php</b> on line <b>135</b> 
[2023-07-19 13:59:39] ERROR: <br>PHP warning : <em>Undefined variable $user_categories</em> in <b>C:\xampp\htdocs\booking-main!\modules\index\models\register.php</b> on line <b>135</b> 
[2023-07-19 13:59:39] ERROR: <br>PHP warning : <em>foreach() argument must be of type array|object, null given</em> in <b>C:\xampp\htdocs\booking-main!\modules\index\models\register.php</b> on line <b>135</b> 
[2023-07-19 14:01:37] ERROR: <br>PHP warning : <em>Undefined variable $user_categories</em> in <b>C:\xampp\htdocs\booking-main!\modules\index\models\register.php</b> on line <b>135</b> 
[2023-07-19 14:01:37] ERROR: <br>PHP warning : <em>foreach() argument must be of type array|object, null given</em> in <b>C:\xampp\htdocs\booking-main!\modules\index\models\register.php</b> on line <b>135</b> 
[2023-07-19 14:03:27] ERROR: <br>PHP warning : <em>Undefined variable $user_categories</em> in <b>C:\xampp\htdocs\booking-main!\modules\index\models\register.php</b> on line <b>135</b> 
[2023-07-19 14:03:27] ERROR: <br>PHP warning : <em>foreach() argument must be of type array|object, null given</em> in <b>C:\xampp\htdocs\booking-main!\modules\index\models\register.php</b> on line <b>135</b> 
[2023-07-19 15:19:25] ERROR: <br>PHP warning : <em>Undefined variable $thumb</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\rooms.php</b> on line <b>101</b> 
[2023-07-19 15:19:25] ERROR: <br>PHP warning : <em>Undefined variable $thumb</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\rooms.php</b> on line <b>101</b> 
[2023-07-19 15:19:25] ERROR: <br>PHP warning : <em>Undefined variable $thumb</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\rooms.php</b> on line <b>101</b> 
[2023-07-19 15:19:25] ERROR: <br>PHP warning : <em>Undefined variable $thumb</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\rooms.php</b> on line <b>101</b> 
[2023-07-19 15:19:25] ERROR: <br>PHP warning : <em>Undefined variable $thumb</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\rooms.php</b> on line <b>101</b> 
[2023-07-19 15:19:25] ERROR: <br>PHP warning : <em>Undefined variable $thumb</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\rooms.php</b> on line <b>101</b> 
[2023-07-19 15:19:25] ERROR: <br>PHP warning : <em>Undefined variable $thumb</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\rooms.php</b> on line <b>101</b> 
[2023-07-19 15:19:25] ERROR: <br>PHP warning : <em>Undefined variable $thumb</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\rooms.php</b> on line <b>101</b> 
[2023-07-19 15:24:10] ERROR: <br>Exception : <em>call_user_func(): Argument #1 ($callback) must be a valid callback, class Booking\Rooms\View does not have a method "onRow"</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\DataTable.php</b> on line <b>903</b> 
[2023-07-19 16:08:27] ERROR: <br>PHP warning : <em>require(C:/xampp/htdocs/booking-main/Kotchasan/Http/Message.php): Failed to open stream: No such file or directory</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\load.php</b> on line <b>412</b> 
[2023-07-19 16:08:27] ERROR: <br>Exception : <em>Failed opening required 'C:/xampp/htdocs/booking-main/Kotchasan/Http/Message.php' (include_path='\xampp\php\PEAR')</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\load.php</b> on line <b>412</b> 
[2023-07-19 16:18:19] ERROR: <br>PHP warning : <em>Undefined variable $user_categories</em> in <b>C:\xampp\htdocs\booking-main\modules\index\models\register.php</b> on line <b>135</b> 
[2023-07-19 16:18:19] ERROR: <br>PHP warning : <em>foreach() argument must be of type array|object, null given</em> in <b>C:\xampp\htdocs\booking-main\modules\index\models\register.php</b> on line <b>135</b> 
[2023-07-20 08:36:57] ERROR: <br>PHP warning : <em>require(C:/xampp/htdocs/booking-main/Kotchasan/Language.php): Failed to open stream: No such file or directory</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\load.php</b> on line <b>412</b> 
[2023-07-20 08:36:57] ERROR: <br>Exception : <em>Failed opening required 'C:/xampp/htdocs/booking-main/Kotchasan/Language.php' (include_path='\xampp\php\PEAR')</em> in <b>C:\xampp\htdocs\booking-main\Gcms\Category.php</b> on line <b>85</b> 
[2023-07-20 08:37:02] ERROR: <br>PHP warning : <em>require(C:/xampp/htdocs/booking-main/Kotchasan/Language.php): Failed to open stream: No such file or directory</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\load.php</b> on line <b>412</b> 
[2023-07-20 08:37:02] ERROR: <br>Exception : <em>Failed opening required 'C:/xampp/htdocs/booking-main/Kotchasan/Language.php' (include_path='\xampp\php\PEAR')</em> in <b>C:\xampp\htdocs\booking-main\Gcms\Category.php</b> on line <b>85</b> 
[2023-07-20 08:47:32] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>C:\xampp\htdocs\booking-main\modules\index\views\editprofile.php</b> on line <b>158</b> 
[2023-07-20 11:06:07] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:06:07] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:06:21] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:06:21] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:07:35] ERROR: <br>PHP warning : <em>Undefined variable $user_categories</em> in <b>C:\xampp\htdocs\booking-main\modules\index\models\register.php</b> on line <b>135</b> 
[2023-07-20 11:07:35] ERROR: <br>PHP warning : <em>foreach() argument must be of type array|object, null given</em> in <b>C:\xampp\htdocs\booking-main\modules\index\models\register.php</b> on line <b>135</b> 
[2023-07-20 11:07:57] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:07:57] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:09:12] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\controllers\index.php</b> on line <b>45</b> 
[2023-07-20 11:10:24] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:10:24] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:10:41] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:10:41] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:11:32] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:11:32] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:13:14] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:13:14] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:13:38] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:13:38] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:14:20] ERROR: <br>PHP warning : <em>Undefined variable $user_categories</em> in <b>C:\xampp\htdocs\booking-main\modules\index\models\register.php</b> on line <b>135</b> 
[2023-07-20 11:14:20] ERROR: <br>PHP warning : <em>foreach() argument must be of type array|object, null given</em> in <b>C:\xampp\htdocs\booking-main\modules\index\models\register.php</b> on line <b>135</b> 
[2023-07-20 11:14:36] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:14:36] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:17:41] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'sex' in 'field list'</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-20 11:17:45] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'sex' in 'field list'</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-20 11:18:00] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'sex' in 'field list'</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-20 11:18:29] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'sex' in 'field list'</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-20 11:18:45] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'sex' in 'field list'</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-20 11:18:46] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'sex' in 'field list'</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-20 11:18:46] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'sex' in 'field list'</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-20 11:18:46] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'sex' in 'field list'</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-20 11:18:47] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'sex' in 'field list'</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-20 11:18:47] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'sex' in 'field list'</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-20 11:18:47] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'sex' in 'field list'</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-20 11:18:47] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'sex' in 'field list'</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-20 11:18:49] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'sex' in 'field list'</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-20 11:18:50] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'sex' in 'field list'</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-20 11:19:20] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'sex' in 'field list'</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-20 11:29:14] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:29:14] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:30:17] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:30:43] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:31:24] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:32:14] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:32:31] ERROR: <br>PHP warning : <em>Undefined array key "Student_id"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:33:38] ERROR: <br>PHP warning : <em>Undefined array key "Student_id"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:35:40] ERROR: <br>PHP warning : <em>Undefined array key "token"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:37:35] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:38:36] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:39:36] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:41:11] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:43:47] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:46:32] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 11:59:32] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 12:00:28] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 12:01:01] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 12:01:38] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 12:03:01] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 12:04:00] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\detail.php</b> on line <b>77</b> 
[2023-07-20 12:09:59] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 12:10:18] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 12:10:21] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 12:12:37] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:01:06] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:04:11] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:05:51] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:07:07] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:10:51] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:11:14] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:12:22] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:14:16] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:15:43] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:17:14] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:20:40] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:20:59] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:22:06] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:22:59] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:23:39] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\models\booking.php</b> on line <b>108</b> 
[2023-07-20 13:23:40] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\models\booking.php</b> on line <b>108</b> 
[2023-07-20 13:23:40] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\models\booking.php</b> on line <b>108</b> 
[2023-07-20 13:23:40] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\models\booking.php</b> on line <b>108</b> 
[2023-07-20 13:23:53] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:24:12] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:24:30] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\models\booking.php</b> on line <b>108</b> 
[2023-07-20 13:24:35] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\models\booking.php</b> on line <b>108</b> 
[2023-07-20 13:24:35] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\models\booking.php</b> on line <b>108</b> 
[2023-07-20 13:24:35] ERROR: <br>PHP warning : <em>Undefined array key "id_card"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\models\booking.php</b> on line <b>108</b> 
[2023-07-20 13:27:05] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:27:08] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:28:28] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:29:57] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:31:06] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:35:07] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 13:39:56] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 14:50:40] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 14:51:09] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 14:52:17] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 14:53:32] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 14:55:02] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 14:55:06] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 14:58:58] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 14:59:13] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:00:22] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:00:30] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:02:18] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:02:31] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:02:52] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:03:20] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:03:47] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:04:47] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:05:29] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:05:44] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:07:09] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:07:10] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:07:19] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:07:32] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:07:33] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:07:45] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:08:23] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:08:32] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:08:49] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:08:54] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:09:08] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:09:18] ERROR: <br>Exception : <em>Class "Booking\Index\View" not found</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-20 15:09:40] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:09:40] ERROR: <br>Exception : <em>Class "Booking\Index\View" not found</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-20 15:09:57] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:10:11] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:10:22] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:10:37] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:10:50] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:10:53] ERROR: <br>Exception : <em>Class "Booking\Index\View" not found</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-20 15:11:00] ERROR: <br>Exception : <em>Class "Booking\Index\View" not found</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-20 15:11:40] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:11:41] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:12:42] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:12:43] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:13:03] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:13:03] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:13:25] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:13:31] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:13:53] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:13:54] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:14:00] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:14:10] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:14:23] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:14:44] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:14:58] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:15:20] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:15:32] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:15:38] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:15:50] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:15:59] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:16:28] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:17:55] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:19:16] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:19:20] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:19:59] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:20:12] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:20:13] ERROR: <br>Exception : <em>syntax error, unexpected token "=>", expecting ")"</em> in <b>C:\xampp\htdocs\booking-main\modules\index\controllers\loader.php</b> on line <b>67</b> 
[2023-07-20 15:20:17] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:21:10] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:21:15] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:22:01] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:22:12] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:22:13] ERROR: <br>Exception : <em>Unclosed '{' on line 48 does not match ')'</em> in <b>C:\xampp\htdocs\booking-main\modules\index\controllers\loader.php</b> on line <b>67</b> 
[2023-07-20 15:22:15] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:23:25] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:23:33] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:25:41] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:29:36] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:29:45] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:29:51] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:29:52] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:36:25] ERROR: <br>Exception : <em>Class "Booking\Index\View" not found</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-20 15:37:07] ERROR: <br>Exception : <em>Unclosed '{' on line 48 does not match ')'</em> in <b>C:\xampp\htdocs\booking-main\modules\index\controllers\loader.php</b> on line <b>67</b> 
[2023-07-20 15:40:23] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:40:30] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:40:32] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:40:35] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:41:00] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:41:01] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 15:41:01] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 16:08:47] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-20 16:09:16] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:00:16] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:20:44] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:21:08] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:23:37] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:25:52] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:26:34] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:26:42] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:27:29] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:27:33] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:28:28] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:28:28] ERROR: <br>PHP warning : <em>Undefined array key "ผู้ขอ"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\index.php</b> on line <b>199</b> 
[2023-07-21 08:28:28] ERROR: <br>PHP warning : <em>Undefined array key "ผู้ขอ"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\index.php</b> on line <b>199</b> 
[2023-07-21 08:28:37] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:29:42] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:33:30] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:33:30] ERROR: <br>Exception : <em>syntax error, unexpected single-quoted string "<div class=two_lines><b>"</em> in <b>C:\xampp\htdocs\booking-main\modules\index\controllers\loader.php</b> on line <b>67</b> 
[2023-07-21 08:34:36] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:34:36] ERROR: <br>Exception : <em>syntax error, unexpected single-quoted string "<div class=two_lines><b>"</em> in <b>C:\xampp\htdocs\booking-main\modules\index\controllers\loader.php</b> on line <b>67</b> 
[2023-07-21 08:34:52] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:35:10] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:35:25] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:37:27] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:37:36] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:39:14] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:39:48] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:40:45] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:47:38] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:47:53] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:48:02] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:49:18] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:50:10] ERROR: <br>Exception : <em>syntax error, unexpected token "{", expecting "function" or "const"</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Html.php</b> on line <b>122</b> 
[2023-07-21 08:50:15] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:50:20] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:53:19] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:53:33] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:55:34] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:55:59] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:56:05] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 08:56:23] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 09:00:23] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 09:00:28] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 09:01:22] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 09:03:02] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 09:03:14] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 09:03:14] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 09:13:49] ERROR: <br>Exception : <em>implode(): Argument #1 ($pieces) must be of type array, string given</em> 
[2023-07-21 09:15:11] ERROR: <br>PHP warning : <em>Undefined array key "ว่า"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\index.php</b> on line <b>199</b> 
[2023-07-21 09:15:11] ERROR: <br>PHP warning : <em>Undefined array key "ว่า"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\index.php</b> on line <b>199</b> 
[2023-07-21 09:15:26] ERROR: <br>Exception : <em>Call to undefined function </b><small class=block>()</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\DataTable.php</b> on line <b>1047</b> 
[2023-07-21 09:16:50] ERROR: <br>Exception : <em>syntax error, unexpected variable "$item", expecting "function" or "const"</em> in <b>C:\xampp\htdocs\booking-main\modules\index\controllers\loader.php</b> on line <b>67</b> 
[2023-07-21 09:16:54] ERROR: <br>Exception : <em>syntax error, unexpected variable "$item", expecting "function" or "const"</em> in <b>C:\xampp\htdocs\booking-main\modules\index\controllers\loader.php</b> on line <b>67</b> 
[2023-07-21 09:24:28] ERROR: <br>Exception : <em>implode(): Argument #1 ($pieces) must be of type array, string given</em> 
[2023-07-21 09:25:57] ERROR: <br>PHP warning : <em>Undefined array key ";jk"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\index.php</b> on line <b>200</b> 
[2023-07-21 09:25:57] ERROR: <br>PHP warning : <em>Undefined array key ";jk"</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\index.php</b> on line <b>200</b> 
[2023-07-21 09:31:03] ERROR: <br>Exception : <em>syntax error, unexpected token "array"</em> in <b>C:\xampp\htdocs\booking-main\modules\index\controllers\loader.php</b> on line <b>67</b> 
[2023-07-21 09:35:07] ERROR: <br>Exception : <em>implode(): Argument #1 ($separator) must be of type string, array given</em> 
[2023-07-21 09:35:20] ERROR: <br>Exception : <em>implode(): Argument #2 ($array) must be of type ?array, string given</em> 
[2023-07-21 09:35:21] ERROR: <br>Exception : <em>implode(): Argument #2 ($array) must be of type ?array, string given</em> 
[2023-07-21 09:35:23] ERROR: <br>Exception : <em>implode(): Argument #2 ($array) must be of type ?array, string given</em> 
[2023-07-21 09:40:11] ERROR: <br>PHP warning : <em>Undefined variable $k</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\report.php</b> on line <b>206</b> 
[2023-07-21 09:40:11] ERROR: <br>PHP warning : <em>Undefined variable $k</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\report.php</b> on line <b>206</b> 
[2023-07-21 09:40:11] ERROR: <br>PHP warning : <em>Undefined variable $k</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\report.php</b> on line <b>206</b> 
[2023-07-21 09:40:11] ERROR: <br>PHP warning : <em>Undefined variable $k</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\report.php</b> on line <b>206</b> 
[2023-07-21 09:45:07] ERROR: <br>Exception : <em>Undefined constant "Booking\Report\topic"</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\DataTable.php</b> on line <b>1047</b> 
[2023-07-21 09:45:41] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 09:47:34] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 09:47:54] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:05:48] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:10:39] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:10:41] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:10:41] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:10:42] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:10:42] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:10:48] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:10:49] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:10:49] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:10:49] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:10:54] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:11:06] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:11:20] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:13:39] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:13:40] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:13:57] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:14:54] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:15:00] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:15:01] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:15:02] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:15:06] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:18:30] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:18:37] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:19:19] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:19:30] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:19:42] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:19:55] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:20:08] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:20:23] ERROR: <br>Exception : <em>Class "Booking\Booking\Model" not found</em> in <b>C:\xampp\htdocs\booking-main\modules\index\controllers\index.php</b> on line <b>67</b> 
[2023-07-21 10:20:29] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:20:49] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:21:21] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:22:41] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:23:01] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:24:08] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:24:57] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:26:27] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:26:33] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:26:33] ERROR: <br>Exception : <em>Class "Booking\Order\Model" not found</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-21 10:26:44] ERROR: <br>Exception : <em>Class "Booking\Order\Model" not found</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-21 10:26:54] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:27:37] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:27:49] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:28:31] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:29:06] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:29:06] ERROR: <br>Exception : <em>Call to undefined method Booking\Order\Model::get()</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Router.php</b> on line <b>70</b> 
[2023-07-21 10:29:28] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:29:28] ERROR: <br>Exception : <em>SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'A.`name` AS `approver_name`,M1.`value` AS `use`,M2.`value` AS `department`,M3...' at line 1</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Database\Driver.php</b> on line <b>254</b> 
[2023-07-21 10:29:35] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:29:52] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:33:43] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:33:43] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'ว่า1.value use' in 'field list'</em> in <b>C:\xampp\htdocs\booking-main\Kotchasan\Database\Driver.php</b> on line <b>254</b> 
[2023-07-21 10:33:51] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:35:54] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:36:03] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:36:09] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:36:11] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:36:29] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:41:15] ERROR: <br>PHP warning : <em>Undefined variable $user_categories</em> in <b>C:\xampp\htdocs\booking-main\modules\index\models\register.php</b> on line <b>135</b> 
[2023-07-21 10:41:15] ERROR: <br>PHP warning : <em>foreach() argument must be of type array|object, null given</em> in <b>C:\xampp\htdocs\booking-main\modules\index\models\register.php</b> on line <b>135</b> 
[2023-07-21 10:42:00] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:44:19] ERROR: <br>PHP warning : <em>Undefined variable $user_categories</em> in <b>C:\xampp\htdocs\booking-main\modules\index\models\register.php</b> on line <b>135</b> 
[2023-07-21 10:44:19] ERROR: <br>PHP warning : <em>foreach() argument must be of type array|object, null given</em> in <b>C:\xampp\htdocs\booking-main\modules\index\models\register.php</b> on line <b>135</b> 
[2023-07-21 10:47:40] ERROR: <br>PHP warning : <em>Undefined variable $user_categories</em> in <b>C:\xampp\htdocs\booking-main\modules\index\models\register.php</b> on line <b>135</b> 
[2023-07-21 10:47:41] ERROR: <br>PHP warning : <em>foreach() argument must be of type array|object, null given</em> in <b>C:\xampp\htdocs\booking-main\modules\index\models\register.php</b> on line <b>135</b> 
[2023-07-21 10:48:25] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:53:29] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 10:57:20] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 11:05:30] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 11:06:50] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 11:06:52] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 11:11:14] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 11:11:15] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 11:11:15] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 11:11:21] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 11:13:12] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 11:53:11] ERROR: <br>PHP warning : <em>Undefined variable $user_categories</em> in <b>C:\xampp\htdocs\booking-main\modules\index\models\register.php</b> on line <b>135</b> 
[2023-07-21 11:53:11] ERROR: <br>PHP warning : <em>foreach() argument must be of type array|object, null given</em> in <b>C:\xampp\htdocs\booking-main\modules\index\models\register.php</b> on line <b>135</b> 
[2023-07-21 11:54:24] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 15:10:21] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-07-21 15:18:38] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-08-10 10:23:41] ERROR: <br>PHP warning : <em>Undefined variable $user_categories</em> in <b>C:\xampp\htdocs\booking-main\modules\index\models\register.php</b> on line <b>135</b> 
[2023-08-10 10:23:41] ERROR: <br>PHP warning : <em>foreach() argument must be of type array|object, null given</em> in <b>C:\xampp\htdocs\booking-main\modules\index\models\register.php</b> on line <b>135</b> 
[2023-08-10 10:24:06] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-08-22 15:34:51] ERROR: <br>PHP warning : <em>Undefined variable $user_categories</em> in <b>C:\xampp\htdocs\booking-main\modules\index\models\register.php</b> on line <b>135</b> 
[2023-08-22 15:34:51] ERROR: <br>PHP warning : <em>foreach() argument must be of type array|object, null given</em> in <b>C:\xampp\htdocs\booking-main\modules\index\models\register.php</b> on line <b>135</b> 
[2023-08-22 15:38:34] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 
[2023-08-22 15:39:08] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$id_card</em> in <b>C:\xampp\htdocs\booking-main\modules\booking\views\booking.php</b> on line <b>108</b> 